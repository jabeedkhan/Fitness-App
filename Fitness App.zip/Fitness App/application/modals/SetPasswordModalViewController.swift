//
//  SetPasswordModalViewController.swift
//  application
//
//  Created by jabeed on 15/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

//extension SetPasswordModalViewController: sendMobileDelegate{
//    
//    func sendMobile(mobile: String) {
//        self.mobile = mobile
//        print(self.mobile,"hey")
//    }
//}

extension SetPasswordModalViewController: SendValueDelegate{
    
    func send(dic: [String : Any], tag: Int) {
        
        self.jsonDict = dic
        
        switch tag {
        case 1:
            setPassword(jsonDict: jsonDict)
        case 2:
            setMPIN(jsonDict: jsonDict)
        default:
            print("Internal Error")
        }
    }
    
}

class SetPasswordModalViewController: UIViewController {

 
    @IBOutlet weak var setPassPopView: UIView!
    @IBOutlet weak var mPINTextField: UITextField!
    var dbutton: UIButton = UIButton()
    @IBOutlet weak var saveButton: RoundButton!
    @IBOutlet weak var passTextField: UITextField!
    @IBOutlet weak var passwordLabel: UILabel!
    @IBOutlet weak var mPinLabel: UILabel!
    
    var mpIN = false
    var pass = false
    let user_type = "m"
    var mobile = ""
    var jsonDict: [String:Any] = [:]
    var data: [String : Any] = [:]
    
    override func viewDidLoad() {
        
        
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        
        dbutton.frame = self.view.frame
        dbutton.setTitle("", for: .normal)
        dbutton.addTarget(self, action: #selector(dismissPopup), for: .touchUpInside)
        
        
        
//        setPassPopView.layer.cornerRadius = 10
//        setPassPopView.layer.masksToBounds = true
         setPassPopView.frame = CGRect(x: 0, y: (self.view.frame.height/2) - 50 , width: self.view.frame.size.width * 0.9, height: self.view.frame.size.height * 0.34)
//         setPassPopView.center = self.view.center
         setPassPopView.backgroundColor = UIColorFromHex(rgbValue: 0xffffff, alpha: 1)
         setPassPopView.clipsToBounds = true
         setPassPopView.layer.cornerRadius = 10
        
        
        saveButton.isEnabled = false
        saveButton.isHighlighted = false
        passwordLabel.isHidden = true
        mPinLabel.isHidden = true
        setBorder(textField: passTextField)
        setBorder(textField: mPINTextField)
        passTextField.becomeFirstResponder()
        
    }
    
    @objc func dismissPopup() {
//        popUpView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width * 0.9, height: self.view.frame.size.height * 0.34)
//        popUpView.center = view.center
        self.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func cancelButtob(_ sender: Any) {
        
        performSegue(withIdentifier: "home", sender: self)
    }
    
    @IBAction func savebutton(_ sender: Any) {
        
        if mpIN{
            if mPINTextField.text?.count != 4 {
                displayAlert(userMessage: "MPIN must be of 4 digits")
            }
            else{
                let parameter = ["":"\n","user_type" : user_type,"mobile": mobile,"mpin":  mPINTextField.text!,"password":""] as [String : Any]
                let set = connectServer(ur: "registrationRoute.php?action=resetCredentials", parameters: parameter as [String : Any], tag: 2)
                set.posts()
                set.sendDelegate = self as SendValueDelegate
                performSegue(withIdentifier: "home", sender: self)
            }
        }
        else if pass{
            if passTextField.text!.count < 16 {
                displayAlert(userMessage: "Password must be of atleast 16 characters")
            }
            else{
                let parameter = ["user_type" : user_type,"mobile": mobile,"mpin": "","password": passTextField.text!] as [String : Any]
                let set = connectServer(ur: "action=resetCredentials", parameters: parameter as [String : Any], tag: 1)
                set.posts()
                set.sendDelegate = self as SendValueDelegate
                performSegue(withIdentifier: "home", sender: self)
            }
        }
    }
    
    
    @IBAction func passTextTyping(_ sender: Any) {
        
        passwordLabel.isHidden = false
        mPINTextField.isEnabled = false
        saveButton.isEnabled = true
        pass = true
        mpIN = false
        
        if passTextField.text!.isEmpty{
            passwordLabel.isHidden = true
            mPINTextField.isEnabled = true
            saveButton.isEnabled = false
        }
        
    }

    @IBAction func mPinTextTyping(_ sender: Any) {
    
        mPinLabel.isHidden = false
        passTextField.isEnabled = false
        saveButton.isEnabled = true
        mpIN = true
        pass = false
    
        if mPINTextField.text!.isEmpty{
            mPinLabel.isHidden = true
            passTextField.isEnabled = true
            saveButton.isEnabled = false
        }
    }
    
    func setPassword(jsonDict: [String : Any]){
        print(jsonDict["message"]!)
    }

    func setMPIN(jsonDict: [String : Any]){
        print(jsonDict["message"]!)
    }

    func setBorder(textField: UITextField){
        
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.orange.cgColor
        border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width, height: textField.frame.size.height)
        border.borderWidth = width
        textField.layer.addSublayer(border)
        textField.layer.masksToBounds = true
    }

    func displayAlert(userMessage: String) {
        
        let myAlert = UIAlertController(title: userMessage, message: "" , preferredStyle: UIAlertController.Style.alert)
        let okAction: UIAlertAction!
        okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
    }

    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    
}
