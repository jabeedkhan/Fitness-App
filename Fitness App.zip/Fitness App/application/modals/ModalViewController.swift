//
//  ModalViewController.swift
//  application
//
//  Created by jabeed on 14/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

protocol sendMobileDelegate {
    func sendMobile(mobile: String)
}



extension ModalViewController: SendValueDelegate {
    
    func send(dic: [String : Any], tag: Int) {
        
        self.jsonDict = dic
        
        switch tag {
        case 1:
            get(jsonDict: dic)
        case 2:
           validateOTP(jsonDict: dic)
        default:
            print("Internal Error")
        }
    }
}

class ModalViewController: UIViewController {

    @IBOutlet weak var popUpView: UIView!
    var dbutton: UIButton = UIButton()
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var mobileTextField: UITextField!
    @IBOutlet weak var notFoundLabel: UILabel!
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    let defaults = UserDefaults.standard
    var jsonDict: [String:Any] = [:]
    var data: [String : Any] = [:]
    
     var passMobileDelegate: sendMobileDelegate? = nil
    
    var otpTextField: UITextField = UITextField()

     let button = UIButton(type: .roundedRect)
     let enterOTPlabel  = UILabel(frame: CGRect(x: 46, y: 200, width: 119, height: 21))
     let invalidOTPlabel  = UILabel(frame: CGRect(x: 46, y: 270, width: 119, height: 21))

     var OTP = ""
     let user_type = "m"
     var mobs = ""
    
//    let videoLengthLabel: UILabel = {
//                let label =  UILabel(frame: CGRect(x: 630, y: 670, width: 54, height: 21))
//                label.translatesAutoresizingMaskIntoConstraints = false
//                label.text = "00:00"
//                label.textColor = .white
//                label.font = UIFont.boldSystemFont(ofSize: 18)
//                label.textAlignment = .right
//                return label
//            }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        popUpView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width * 0.9, height: self.view.frame.size.height * 0.34)
        popUpView.center = self.view.center
        popUpView.backgroundColor = UIColorFromHex(rgbValue: 0xffffff, alpha: 1)
        popUpView.clipsToBounds = true
        popUpView.layer.cornerRadius = 10
        
//        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        self.hideKeyboardWhenTappedAround()
        
        dbutton.frame = self.view.frame
        dbutton.setTitle("", for: .normal)
        dbutton.addTarget(self, action: #selector(dismissPopup), for: .touchUpInside)
       
        
         self.view.addSubview(dbutton)
        self.view.addSubview(popUpView)
//        popUpView.layer.cornerRadius = 10
        popUpView.layer.masksToBounds = true
//        popUpView.frame.origin.y = view.frame.height/2 - 100
        notFoundLabel.isHidden = true
       
        activityIndicator.isHidden = true
        setBorder(textField: mobileTextField)
        otpTextField.keyboardType =
            UIKeyboardType.numberPad
        mobileTextField.becomeFirstResponder()
        
    }
    @objc func dismissPopup() {
        popUpView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width * 0.9, height: self.view.frame.size.height * 0.34)
        popUpView.center = view.center
        self.dismiss(animated: true, completion: nil)
    }
    
    func validate(mobile: String)  {
        
        let parameter = ["user_type" : user_type,"mobile": mobile]
        let val = connectServer(ur: "registrationRoute.php?action=validateMobile", parameters: parameter as [String : Any], tag: 1)
        val.posts()
        val.sendDelegate = self as SendValueDelegate
        
    }
    
    @IBAction func textFieldEditingChanged(_ sender: Any) {
        
        titleLabel.text = "Enter Mobile No."
//        popUpView.frame = CGRect(x: 20, y: 333, width: 374, height: 186)
        notFoundLabel.isHidden = true
        if mobileTextField.text?.count == 10 {
            activityIndicator.isHidden = false
            mobs = mobileTextField.text!
            activityIndicator.startAnimating()
            validate(mobile: mobileTextField.text!)
        }
    }
    
    func addingElements() {
        
        //adding label: Enter OTP-------
        enterOTPlabel.text = "Enter OTP"
        enterOTPlabel.textColor = #colorLiteral(red: 0.9010992646, green: 0.3840323389, blue: 0.2851870954, alpha: 1)
        popUpView.addSubview(enterOTPlabel)
        //------------------------------
        
        //adding label: invalid OTP-------
        invalidOTPlabel.text = "Invalid OTP"
        invalidOTPlabel.textColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
        invalidOTPlabel.isHidden = true
        popUpView.addSubview(invalidOTPlabel)
        //------------------------------
        
        //adding button-----------------
        button.frame = CGRect(x: 200, y: 281, width: 100, height: 50)
        button.backgroundColor = #colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)
        button.layer.cornerRadius = 10
        button.tintColor = UIColor.white
        button.setTitle("RESEND OTP", for: .normal)
        button.addTarget(self, action: #selector(resendButtonPressed), for: .touchUpInside)
        popUpView.addSubview(button)
        //------------------------------
        
        
        //adding textfield--------------
         let otpTextField = UITextField(frame: CGRect(x: 46, y: 225, width: mobileTextField.frame.width, height: 35))
        otpTextField.tintColor = #colorLiteral(red: 0.9010992646, green: 0.3840323389, blue: 0.2851870954, alpha: 1)
        setBorder(textField: otpTextField)
        otpTextField.addTarget(self, action: #selector(otpfieldEditingChanged), for: UIControl.Event.editingChanged)
        popUpView.addSubview(otpTextField)
        //------------------------------
    }
    
    func changeView(view: UIView){
        
        titleLabel.text = "Verify Mobile No."
        popUpView.frame = CGRect(x: popUpView.frame.origin.x, y: popUpView.frame.origin.y - 150, width: self.view.frame.size.width * 0.9, height: self.popUpView.frame.size.height * 1.5)
        
//        popUpView.frame = CGRect(x: 20, y: 250, width: 374, height: popUpView.frame.height + 170)
        addingElements()
        
    }
    
    func validateOTP(jsonDict: [String: Any]) {
        
        data = (jsonDict["data"] as?  [String: Any])!
       
    }
    
    @objc func resendButtonPressed() {
       
        let parameter = ["user_type" : user_type,"mobile": mobileTextField.text!, "signup": 0] as [String : Any]
        let sendOTP = connectServer(ur: "registrationRoute.php?action=sendOtp", parameters: parameter as [String : Any], tag: 2)
        sendOTP.posts()
        sendOTP.sendDelegate = self as SendValueDelegate
        
    }
    
    @objc func otpfieldEditingChanged(){
        
        invalidOTPlabel.isHidden = true
        data = (jsonDict["data"] as?  [String: Any])!
        let otp = otpTextField.text
        if otp!.count == 4 {
            otpTextField.isEnabled = false
            if  otp == "\(data["otp"]!)" {
                let setVC : SetPasswordModalViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "setPassword") as! SetPasswordModalViewController
                setVC.mobile = mobs
                self.present(setVC, animated: true, completion: nil)
//                performSegue(withIdentifier: "setPasswordModal", sender: Any?.self)
            }
            else{
                otpTextField.isEnabled = true
                invalidOTPlabel.isHidden = false
            }
        }
        else if otp!.count > 4 {
              invalidOTPlabel.isHidden = false
        }
        
    }
    func setBorder(textField: UITextField){
    
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.orange.cgColor
        border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width, height: textField.frame.size.height)
        border.borderWidth = width
        textField.layer.addSublayer(border)
        textField.layer.masksToBounds = true
}
    
    
    
    func get(jsonDict: [String:Any])  {
        
        mobileTextField.resignFirstResponder()
        otpTextField.becomeFirstResponder()
        activityIndicator.stopAnimating()
          activityIndicator.isHidden = true
        let data = jsonDict["data"] as?  [String: Any]
        if jsonDict["error"]  as! Int == 1 && data?["userid"] != nil {
            activityIndicator.stopAnimating()
            mobileTextField.isEnabled = false
            let parameter = ["user_type" : user_type,"mobile": mobileTextField.text!, "signup": 0] as [String : Any]
            let sendOTP = connectServer(ur: "registrationRoute.php?action=sendOtp", parameters: parameter as [String : Any], tag: 2)
            sendOTP.posts()
            sendOTP.sendDelegate = self as SendValueDelegate
            changeView(view: popUpView)
        }
        else{
            activityIndicator.stopAnimating()
            activityIndicator.isHidden = true
            notFoundLabel.isHidden = false
        }    }
    
    func displayAlert(userMessage: String) {
        
        let myAlert = UIAlertController(title: userMessage, message: "" , preferredStyle: UIAlertController.Style.alert)
        let okAction: UIAlertAction!
        okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
    }
    
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.popUpView.frame.origin.y != 0 {
                self.popUpView.frame.origin.y -= keyboardSize.height + 10
            }
        }
    }
    
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
//             self.popUpView.frame.origin.y -=  70
        if self.view.frame.origin.y != 0 {
//             popUpView.center = view.center
                popUpView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width * 0.9, height: self.view.frame.size.height * 0.34)
        }
        }
    }
}



