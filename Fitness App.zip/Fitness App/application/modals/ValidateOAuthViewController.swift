//
//  ValidateOAuthViewController.swift
//  application
//
//  Created by jabeed on 18/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

extension ValidateOAuthViewController: SendValueDelegate {
    
    func send(dic: [String : Any], tag: Int) {
        
        self.jsonDict = dic
        
        switch tag {
        case 3:
            validateNumber(jsonDict: dic)
        case 4:
            validatePassword(jsonDict: dic)
        default:
            print("Internal Error")
        }
    }
}

class ValidateOAuthViewController: UIViewController {

    @IBOutlet weak var popView: UIView!
    @IBOutlet weak var mobileTextField: UITextField!
    @IBOutlet weak var activity: UIActivityIndicatorView!
    @IBOutlet weak var notFoundLabel: UILabel!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    var jsonDict: [String: Any] = [:]
    
    var name:String = ""
    var email:String = ""
    var id:String = ""
    var userid: String = ""
    
    var dbutton = UIButton()
    
    let passwordTextField = UITextField(frame: CGRect(x: 46, y: 225, width: 282, height: 35))
    
    let button = UIButton(type: .roundedRect)
    
    let enterpasslabel  = UILabel(frame: CGRect(x: 46, y: 200, width: 119, height: 21))
    
    let invalidpasslabel  = UILabel(frame: CGRect(x: 46, y: 270, width: 130, height: 21))
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        popView.layer.cornerRadius = 10
        popView.layer.masksToBounds = true
        setBorder(textField: mobileTextField)
        
        self.hideKeyboardWhenTappedAround()
        
        dbutton.frame = self.view.frame
        dbutton.setTitle("", for: .normal)
        dbutton.addTarget(self, action: #selector(dismissPopup), for: .touchUpInside)
        
        self.view.addSubview(dbutton)
        
        notFoundLabel.isHidden = true
        mobileTextField.becomeFirstResponder()
        activity.isHidden = true
    }
    
    @objc func dismissPopup() {
//        popUpView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width * 0.9, height: self.view.frame.size.height * 0.34)
//        popUpView.center = view.center
        self.dismiss(animated: true, completion: nil)
    }
    
    
    func setBorder(textField: UITextField){
        
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.orange.cgColor
        border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width, height: textField.frame.size.height)
        border.borderWidth = width
        textField.layer.addSublayer(border)
        textField.layer.masksToBounds = true
    }
    
    func validateNumber(jsonDict: [String: Any]){
        
        mobileTextField.resignFirstResponder()
        let data = jsonDict["data"] as?  [String: Any]
        userid = data?["userid"] as! String
        if jsonDict["error"]  as! Int == 0 && !userid.isEmpty  {
            activity.stopAnimating()
            changeView(view: popView)
        }
        else{
            activity.stopAnimating()
            notFoundLabel.isHidden = false
        }
        activity.isHidden = true
    }
    
    func validatePassword(jsonDict: [String: Any]){
        
        if jsonDict["error"]  as! Int == 1{
            invalidpasslabel.isHidden = false
        }
        else{
            dismiss(animated: true, completion: nil)
        }
       
    }
    
    
    
    func changeView(view: UIView){
        
        titleLabel.text = "Verify Password"
        popView.frame = CGRect(x: 20, y: 160, width: 374, height: popView.frame.height + 170)
        addingElements()
        
    }
    
    func addingElements() {
        
        //adding label: Enter Password-------
        enterpasslabel.text = "Enter Password"
        enterpasslabel.textColor = #colorLiteral(red: 0.9010992646, green: 0.3840323389, blue: 0.2851870954, alpha: 1)
        popView.addSubview(enterpasslabel)
        //------------------------------
        
        //adding label: invalid OTP-------
        invalidpasslabel.text = "Invalid Password"
        invalidpasslabel.textColor = #colorLiteral(red: 1, green: 0.1491314173, blue: 0, alpha: 1)
        invalidpasslabel.isHidden = true
        popView.addSubview(invalidpasslabel)
        //------------------------------
        
        //adding button-----------------
        button.frame = CGRect(x: 235, y: 290, width: 100, height: 50)
        button.backgroundColor = #colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)
        button.layer.cornerRadius = 10
        button.tintColor = UIColor.white
        button.setTitle("LOGIN", for: .normal)
        button.isEnabled = false
        button.addTarget(self, action: #selector(saveButtonPressed), for: .touchUpInside)
        popView.addSubview(button)
        //------------------------------
        
        
        //adding textfield--------------
        passwordTextField.tintColor = #colorLiteral(red: 0.9010992646, green: 0.3840323389, blue: 0.2851870954, alpha: 1)
        passwordTextField.becomeFirstResponder()
        setBorder(textField: passwordTextField)
        passwordTextField.addTarget(self, action: #selector(passTextFieldEditingChanged), for: UIControl.Event.editingChanged)
        popView.addSubview(passwordTextField)
        //------------------------------
    }
    
    
    @objc func saveButtonPressed() {
        
        var para = [String : String]()
        para = ["email": email,"id": id, "login": "1", "name": name, "type": "google", "user_type": "m" ]
        let parameter = [ "oauth" : para ,"password":passwordTextField.text!,"username":mobileTextField.text!,"user_type": "m"] as [String : Any]
    
        let sendpass = connectServer(ur: "registrationRoute.php?action=checkCredentials", parameters: parameter as [String : Any], tag: 4)
        sendpass.posts()
        sendpass.sendDelegate = self as SendValueDelegate
        
    }
    
    
    @objc func passTextFieldEditingChanged(){
        
        invalidpasslabel.isHidden = true
        button.isEnabled = true
        
    }
    @IBAction func textFieldEditingChanged(_ sender: Any) {
        
        popView.frame = CGRect(x: 20, y: 333, width: 374, height: 186)
        notFoundLabel.isHidden = true
        if mobileTextField.text?.count == 10 {
            activity.isHidden = false
            activity.startAnimating()
            validate(mobile: mobileTextField.text!)
        }
    }
    func validate(mobile: String)  {
        
        let parameter = ["user_type" : "m","existingUsername": mobile]
        let val = connectServer(ur: "registrationRoute.php?action=verifyMobileEmail", parameters: parameter as [String : Any], tag: 3)
        val.posts()
        val.sendDelegate = self as SendValueDelegate
        
    }
    
    func displayAlert(userMessage: String) {
        
        let myAlert = UIAlertController(title: userMessage, message: "" , preferredStyle: UIAlertController.Style.alert)
        let okAction: UIAlertAction!
        okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
    }
    
    @IBAction func dismissButton(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
        
        
    }
}
