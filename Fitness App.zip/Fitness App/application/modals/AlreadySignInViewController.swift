//
//  AlreadySignInViewController.swift
//  application
//
//  Created by jabeed on 18/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

extension AlreadySignInViewController: SendValueDelegate {
    
    func send(dic: [String : Any], tag: Int) {
        
        self.jsonDict = dic
        
        switch tag {
        case 4:
            validatePassword(jsonDict: dic)
        default:
            print("Internal Error")
        }
    }
}

class AlreadySignInViewController: UIViewController {

    
    @IBOutlet weak var mobileTextField: UITextField!
    
    @IBOutlet weak var passwordTexField: UITextField!
    
    @IBOutlet weak var invalidpassTextfield: UILabel!
    
    
    @IBOutlet weak var popUp: UIView!
    @IBOutlet weak var button: RoundButton!
    @IBOutlet weak var loadingLogin: UIActivityIndicatorView!
    
    @IBOutlet weak var assistView: UIView!
    var username: String = ""
    var name: String = ""
    var id: String = ""
    var jsonDict: [String: Any] = [:]
    var blurEffect = UIBlurEffect()
    var blurEffectView = UIVisualEffectView()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        popUp.layer.cornerRadius = 10
        popUp.layer.masksToBounds = true

        mobileTextField.text = username
        button.isEnabled = false
        invalidpassTextfield.isHidden = true
        mobileTextField.isEnabled = false
        loadingLogin.isHidden = true
        setBorder(textField: mobileTextField)
       
        setBorder(textField: passwordTexField)
        passwordTexField.becomeFirstResponder()

        // Do any additional setup after loading the view.
    }
    
    func setBorder(textField: UITextField){
        
        let border = CALayer()
        let width = CGFloat(2.0)
        border.borderColor = UIColor.orange.cgColor
        border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width, height: textField.frame.size.height)
        border.borderWidth = width
        textField.layer.addSublayer(border)
        textField.layer.masksToBounds = true
    }
    
    
    
    @IBAction func passFieldEditingChanged(_ sender: Any) {
        
        invalidpassTextfield.isHidden = true
        button.isEnabled = true
            }
    
    @IBAction func loginTapped(_ sender: Any) {
        
        loadingLogin.isHidden = false
        loadingLogin.startAnimating()
        
        var para = [String : String]()
        para = ["email": username,"id": id, "login": "1", "name": name, "type": "google", "user_type": "m" ]
        let parameter = [ "oauth" : para ,"password":passwordTexField.text!,"username":username,"user_type": "m"] as [String : Any]
        
        let sendpass = connectServer(ur: "registrationRoute.php?action=checkCredentials", parameters: parameter as [String : Any], tag: 4)
        sendpass.posts()
        sendpass.sendDelegate = self as SendValueDelegate
    }
    
    func validatePassword(jsonDict: [String: Any]){
        
        loadingLogin.stopAnimating()
        if jsonDict["error"]  as! Int == 1{
            invalidpassTextfield.isHidden = false
        }
        else{
            print("welcome")
            dismiss(animated: true, completion: nil)
            blurEffectView.removeFromSuperview()
    }
    }
    func displayAlert(userMessage: String) {
        
        let myAlert = UIAlertController(title: userMessage, message: "" , preferredStyle: UIAlertController.Style.alert)
        let okAction: UIAlertAction!
        okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
    }
    
    @IBAction func dismiss(_ sender: Any) {
        
        dismiss(animated: true, completion: nil)
    }
    
    
}
