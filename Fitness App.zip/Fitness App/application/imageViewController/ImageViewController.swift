//
//  ImageViewController.swift
//  application
//
//  Created by jabeed on 19/09/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class ImageViewController: UIViewController {
    
    var imageName:String?
    var imageURL:String = "https://papa.fit/content/event_image/"

    @IBOutlet weak var imageView: UIImageView!
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.dismiss(animated: false, completion: nil)
    }
    
    override func viewDidLoad() {
    super.viewDidLoad()
    imageURL = imageURL + imageName!
        print(imageURL)
        let nsUrl = URL(string: imageURL)
        let data = try? Data(contentsOf: nsUrl!)
        if let imageData = data {
            let image = UIImage(data: imageData)
            self.imageView.image = image

   }
}
}
