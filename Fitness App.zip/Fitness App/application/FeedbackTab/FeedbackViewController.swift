//
//  FeedbackViewController.swift
//  application
//
//  Created by jabeed on 22/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit
protocol feedValue {
    func feedV(feed: String)
    
    func feedFa(feed:String)
}

class FeedbackViewController: UIViewController,feedValue {
    func feedFa(feed: String) {
        texxtField2.text = feed
    }
    

    @IBOutlet weak var textField: UITextField!
    
    @IBOutlet weak var texxtField2: UITextField!
    
    @IBOutlet weak var textView: UITextView!
    var button = dropDownBtn()
    var button2 = dropDownBtn()
    
    func feedV(feed: String) {
        textField.text = feed
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.hideKeyboardWhenTappedAround()
       
        //Configure the button
        button = dropDownBtn.init(frame: CGRect(x: 210, y: textField.frame.origin.y, width:150, height: 40))
        button.setImage(UIImage(named: "Shape"), for: .normal)
        
        button2 = dropDownBtn.init(frame: CGRect(x: 210, y: texxtField2.frame.origin.y, width:150, height: 40))
        button2.setImage(UIImage(named: "Shape"), for: .normal)
//                button.setTitle("Feedback", for: .normal)
        
        
            button.translatesAutoresizingMaskIntoConstraints = true
        
        button2.translatesAutoresizingMaskIntoConstraints = true
        textField.text = "Excellent"
        texxtField2.text = "Faculty"
        button.del = self
        button2.del = self
        //Add Button to the View Controller
       
        self.view.addSubview(button2)
         self.view.addSubview(button)
        //button Constraints
//
        setBorder(textField: textField)
        setBorder(textField: texxtField2)
//        button.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
//        button.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
//
        button.widthAnchor.constraint(equalToConstant: 250).isActive = true
        button.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        button2.widthAnchor.constraint(equalToConstant: 250).isActive = true
        button2.heightAnchor.constraint(equalToConstant: 40).isActive = true

        //Set the drop down menu's options
        button.dropView.dropDownOptions = ["Excellent", "Good", "Okay", "Bad", "Very Bad"]
        button2.dropView.dropDownOptions = ["Faculty","Administration"]
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setBorder(textField: UITextField){
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor.lightGray.cgColor
        border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width, height: textField.frame.size.height)
        border.borderWidth = width
        textField.layer.addSublayer(border)
        textField.layer.masksToBounds = true
        
        
    }
    
    
    @IBAction func sendButton(_ sender: Any) {
        print(textField.text!)
        print(texxtField2.text!)
        print(textView.text!)
    }
    
    
    @IBAction func backButton(_ sender: Any) {
        performSegue(withIdentifier : "unwind", sender: self)
    }
    
}

protocol dropDownProtocol {
    func dropDownPressed(string : String)
}

class dropDownBtn: UIButton, dropDownProtocol {
    
    func dropDownPressed(string: String) {
//        self.setTitle(string, for: .normal)
        f = string
        if f == "Faculty" || f == "Administration"{
            self.del.feedFa(feed: f)
        }
        else{
            self.del.feedV(feed: f)
        }
        
        self.dismissDropDown()
    }
    var f = ""
    
    var del: feedValue!
    
    var dropView = dropDownView()
    
    var height = NSLayoutConstraint()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    
        self.backgroundColor = UIColor.white
        dropView = dropDownView.init(frame: CGRect.init(x: 0, y: 0, width: 0, height:0))
        dropView.delegate = self
        dropView.translatesAutoresizingMaskIntoConstraints = false
    }
    
    override func didMoveToSuperview() {
        self.superview?.addSubview(dropView)
        self.superview?.bringSubviewToFront(dropView)
        dropView.topAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        dropView.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        dropView.widthAnchor.constraint(equalTo: self.widthAnchor).isActive = true
        height = dropView.heightAnchor.constraint(equalToConstant: 0)
    }
    
    var isOpen = false
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if isOpen == false {
            
            isOpen = true
            
            NSLayoutConstraint.deactivate([self.height])
            
            if self.dropView.tableView.contentSize.height > 250 {
                self.height.constant = 250
            } else {
                self.height.constant = self.dropView.tableView.contentSize.height
            }
            
            
            NSLayoutConstraint.activate([self.height])
            
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
                self.dropView.layoutIfNeeded()
                self.dropView.center.y += self.dropView.frame.height / 2
            }, completion: nil)
            
        } else {
            isOpen = false
            
            NSLayoutConstraint.deactivate([self.height])
            self.height.constant = 0
            NSLayoutConstraint.activate([self.height])
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
                self.dropView.center.y -= self.dropView.frame.height / 2
                self.dropView.layoutIfNeeded()
            }, completion: nil)
        }
    }
    
    func dismissDropDown() {
        isOpen = false
        NSLayoutConstraint.deactivate([self.height])
        self.height.constant = 0
        NSLayoutConstraint.activate([self.height])
        UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: .curveEaseInOut, animations: {
            self.dropView.center.y -= self.dropView.frame.height / 2
            self.dropView.layoutIfNeeded()
        }, completion: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

class dropDownView: UIView, UITableViewDelegate, UITableViewDataSource  {
    
    var dropDownOptions = [String]()
    
    var tableView = UITableView()
    
    var delegate : dropDownProtocol!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        tableView.backgroundColor = UIColor.white
        self.backgroundColor = UIColor.white
        
        
        tableView.delegate = self
        tableView.dataSource = self
        
        tableView.translatesAutoresizingMaskIntoConstraints = false
        
        self.addSubview(tableView)
        
        tableView.leftAnchor.constraint(equalTo: self.leftAnchor).isActive = true
        tableView.rightAnchor.constraint(equalTo: self.rightAnchor).isActive = true
        tableView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        tableView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dropDownOptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        
        cell.textLabel?.text = dropDownOptions[indexPath.row]
        cell.backgroundColor = UIColor.white
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.delegate.dropDownPressed(string: dropDownOptions[indexPath.row])
        self.tableView.deselectRow(at: indexPath, animated: true)
    }
    
    
    
  
}




















