//
//  NotificationTableViewCell.swift
//  application
//
//  Created by jabeed on 20/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class NotificationTableViewCell: UITableViewCell {
    
    @IBOutlet weak var notificationName: UILabel!
    @IBOutlet weak var notificationTime: UILabel!
    @IBOutlet weak var notificationDetails: UILabel!
   
    
    @IBOutlet weak var icon: UIImageView!
    
    
    @IBOutlet weak var cellImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
