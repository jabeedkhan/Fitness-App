//
//  NotificationViewController.swift
//
//
//  Created by jabeed on 20/06/19.
//

import UIKit


extension NotificationViewController: SendValueDelegate{
    
    func send(dic: [String : Any], tag: Int) {
        
        getNotifications(jsonDic: dic)
    }

}

struct notifications {
    let notificationName: String
    let notificationDetail: String
    let notificationTime: String
    let notificationImage: UIImage
    let notificationIcon: UIImage
}

class NotificationViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var loader = ViewControllerUtils()

    @IBOutlet weak var tableView: UITableView!
    
    var data = [notifications]()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return data.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "notificationCell", for: indexPath) as! NotificationTableViewCell
        
         cell.notificationName.text = data[indexPath.row].notificationName
         cell.notificationTime.text = data[indexPath.row].notificationTime
         cell.notificationDetails.text = data[indexPath.row].notificationDetail
         cell.cellImage.image = data[indexPath.row].notificationImage
         cell.icon.image = data[indexPath.row].notificationIcon
        
        if cell.cellImage.image == UIImage(named: "themed-background-leaf"){
            cell.icon.tintColor = #colorLiteral(red: 0.1529411765, green: 0.6823529412, blue: 0.3764705882, alpha: 1)
        }
        else if cell.cellImage.image == UIImage(named: "themed-background-fire"){
            cell.icon.tintColor = #colorLiteral(red: 0.7529411765, green: 0.2235294118, blue: 0.168627451, alpha: 1)
        }
       else if cell.cellImage.image == UIImage(named: "themed-background-asphalt"){
            cell.icon.tintColor = #colorLiteral(red: 0.5647058824, green: 0.5647058824, blue: 0.5647058824, alpha: 1)
        }
       else if cell.cellImage.image == UIImage(named: "themed-background-deepsea"){
            cell.icon.tintColor = #colorLiteral(red: 0, green: 0.3725490196, blue: 0.6117647059, alpha: 1)
        }
        
    
        return cell
    }
    

    override func viewDidLoad() {
        
        super.viewDidLoad()
//        if let items = tabBarController?.tabBar.items {
//            for item in items {
//                item.title = ""
//            }
//        }
//        
//        tabBarItem.title = "Notifications"
//        let appearance = UITabBarItem.appearance()
//        let attributes = [NSAttributedString.Key.font:UIFont(name: "Helvetica", size: 16)]
//        appearance.setTitleTextAttributes(attributes as [NSAttributedString.Key : Any], for: .normal)

        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let str = formatter.string(from: Date())
        loader.showActivityIndicator(uiView: self.view)
        let col = ["title","module_id","action","comment","datetime","mobile_icon","icon_color","record_value","concat_id"]
        let filter = [["bid","=",UserDefaults.standard.string(forKey: "bid")!],["user_type","=","M"],["contact_id","=",UserDefaults.standard.string(forKey: "contact_id")!]]
        
        let order = [["datetime","desc"]]
        
        let parameter: [String: Any] = ["col": col,"filter": filter,"order": order,"limit":"30","offset":0]
        
        let d = connectServer.init(ur:"notificationRoute.php?action=select",parameters: parameter,tag: 0)
        d.token = UserDefaults.standard.string(forKey: "token")!
        d.uid = UserDefaults.standard.string(forKey: "user_id")!
        d.bid = UserDefaults.standard.string(forKey: "bid")!
        d.post1()
        d.sendDelegate = self as SendValueDelegate
        
        
//        data = [notifications.init(notificationName: "Payment Due", notificationDetail: "Seems your payment is due at NIFA. It is time to renew and enjoy hassle-free services.", notificationTime: "12:34 pm", notificationImage: UIImage(named: "OvalPayment")!, notificationIcon: UIImage(named: "baseline_alarm_black_18dp")!)]
//
//        data.append(notifications(notificationName: "Holiday Tomorrow", notificationDetail: "On occasion of Jaya Jayanti, all our branches will remain closed", notificationTime: "09:00 am", notificationImage: UIImage(named: "OvalHoliday")!, notificationIcon: UIImage(named: "baseline_wb_sunny_black_18dp")!))
//
//          data.append(notifications(notificationName: "Ready For a Challenge?", notificationDetail: "Exam is due in 5 days, ready for a big challenge?", notificationTime: "Yesterday", notificationImage: UIImage(named: "OvalChallenge")!, notificationIcon: UIImage(named: "baseline_redeem_black_18dp")!))
//
//        data.append(notifications(notificationName: "Referral Program", notificationDetail: "Ask your friends to nourish their artistic worms at NIFA and you win one month of free extension.", notificationTime: "Yesterday", notificationImage: UIImage(named: "OvalHoliday")!, notificationIcon: UIImage(named: "baseline_brightness_3_black_18dp")!))
//
//          data.append(notifications(notificationName: "Payment Received", notificationDetail: "Team Papa Fit is in love with you, Kushal.You are the reason for their vacation :)", notificationTime: "Mon", notificationImage: UIImage(named: "OvalPaymentRecieved")!, notificationIcon: UIImage(named: "baseline_receipt_blue_18dp")!))

            titleBar()
//        tableView.reloadData()
    }
     var md: [[String:Any]] = [[:]]
    func getNotifications(jsonDic: [String:Any]){
        
        let data1 = jsonDic["data"] as! [Any]
        md.remove(at: 0)
        for i in data1{
            md.append(i as! [String:Any])
            
        }
        
        print(md)
        
//        for t in md{
//            print(t["icon_color"] as! String)
//             let iconColor = t["icon_color"] as! String
//             print(iconColor)
//        }
////
        for t in md{

            let time = t["datetime"] as! String
            let timeS = time.components(separatedBy: " ")
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "HH:mm:ss"
            let date = dateFormatter.date(from: timeS[1])
            dateFormatter.dateFormat = "h:mm a"
            let Date12 = dateFormatter.string(from: date!)
            print(Date12)
            
            if ((t["icon_color"] as! String) == "themed-background-leaf") {
                
                

                if (t["mobile_icon"] as! String) == "ic_puzzle_piece_18"{
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String, notificationImage: UIImage(named: "themed-background-leaf")!, notificationIcon: UIImage(named: "ic_puzzle_piece_18")! ))
                }
                else if (t["mobile_icon"] as! String) == "ic_alarm_black_24dp" {
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String , notificationImage: UIImage(named: "themed-background-leaf")!, notificationIcon: UIImage(named: "ic_alarm_black_24dp")! ))
                }
                else if (t["mobile_icon"] as! String) == "ic_receipt_black_24dp" {
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String , notificationImage: UIImage(named: "themed-background-leaf")!, notificationIcon: UIImage(named: "ic_receipt_black_24dp")! ))
                }
            }
            else if ((t["icon_color"] as! String) == "themed-background-fire") {

                
                if t["mobile_icon"] as! String == "ic_puzzle_piece_18"{
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String , notificationImage: UIImage(named: "themed-background-fire")!, notificationIcon: UIImage(named: "ic_puzzle_piece_18")! ))
                }
                else if t["mobile_icon"] as! String == "ic_alarm_black_24dp" {
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String , notificationImage: UIImage(named: "themed-background-fire")!, notificationIcon: UIImage(named: "ic_alarm_black_24dp")! ))
                }
                else if t["mobile_icon"] as! String == "ic_receipt_black_24dp" {
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String , notificationImage: UIImage(named: "themed-background-fire")!, notificationIcon: UIImage(named: "ic_receipt_black_24dp")! ))
                }

            }
            else if ((t["icon_color"] as! String) == "themed-background-deepsea") {
                if t["mobile_icon"] as! String == "ic_receipt_black_24dp"{
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String , notificationImage: UIImage(named: "themed-background-deepsea")!, notificationIcon: UIImage(named: "ic_receipt_black_24dp")! ))
                }
                else if t["mobile_icon"] as! String == "ic_alarm_black_24dp" {
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String , notificationImage: UIImage(named: "themed-background-deepsea")!, notificationIcon: UIImage(named: "ic_alarm_black_24dp")! ))
                }
                else if t["mobile_icon"] as! String == "ic_puzzle_piece_18" {
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String , notificationImage: UIImage(named: "themed-background-deepsea")!, notificationIcon: UIImage(named: "ic_puzzle_piece_18")! ))
                }

            }else if ((t["icon_color"] as! String) == "themed-background-asphalt") {

                if t["mobile_icon"] as! String == "ic_receipt_black_24dp"{
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String , notificationImage: UIImage(named: "themed-background-asphalt")!, notificationIcon: UIImage(named: "ic_receipt_black_24dp")! ))
                }
                else if t["mobile_icon"] as! String == "ic_alarm_black_24dp" {
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String, notificationImage: UIImage(named: "themed-background-asphalt")!, notificationIcon: UIImage(named: "ic_alarm_black_24dp")! ))
                }
                else if t["mobile_icon"] as! String == "ic_puzzle_piece_18" {
                    data.append(notifications(notificationName: t["title"] as! String, notificationDetail: t["comment"] as! String, notificationTime: t["time_string"] as! String, notificationImage: UIImage(named: "themed-background-asphalt")!, notificationIcon: UIImage(named: "ic_puzzle_piece_18")! ))
                }
            }


        }
        tableView.reloadData()
        loader.hideActivityIndicator(uiView: self.view)
        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
            titleBar()
    }
    
    func titleBar(){
        
        if let items = tabBarController?.tabBar.items {
            for item in items {
                item.title = ""
                item.imageInsets = UIEdgeInsets(top: 0, left: 0, bottom: -10, right: 0)
            }
        }
        tabBarItem.title = "Notifications"
        tabBarItem.imageInsets = UIEdgeInsets(top: 0, left: 0, bottom: -45, right: 0)
        
        let appearance = UITabBarItem.appearance()
        let attributes = [NSAttributedString.Key.font:UIFont(name: "Helvetica Bold", size: 15)]
        appearance.setTitleTextAttributes(attributes as [NSAttributedString.Key : Any], for: .normal)
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
  

    
}
