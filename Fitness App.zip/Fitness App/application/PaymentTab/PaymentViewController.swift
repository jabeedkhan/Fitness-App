//
//  PaymentViewController.swift
//  application
//
//  Created by jabeed on 20/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit


extension PaymentViewController: SendValueDelegate{
    
    func send(dic: [String : Any], tag: Int) {
        
        getPayment(jsonDic: dic)
        
    }
    
    
}
struct payment {
    let paymentName: String
    let paymentDetail: String
    let paymentDate: String
    let payImage: UIImage
}


class PaymentViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var data = [payment]()
    var due = false
    var loader = ViewControllerUtils()
    
    @IBOutlet weak var tableView: UITableView!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return data.count
    }
 
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "paymentCell", for: indexPath) as! PaymentTableViewCell
        
        cell.paymentName.text = data[indexPath.row].paymentName
        cell.paymentDetail.text = data[indexPath.row].paymentDetail
        cell.paymentDate.text = data[indexPath.row].paymentDate
        
        print(data)
        if due{
//            cell.paymentName.text = "Payment due of \(String(describing: UserDefaults.standard.string(forKey: "balance"))) INR"
//            cell.paymentDetail.text = "For \(String(describing: UserDefaults.standard.string(forKey: "category_group"))) subscription"
//            cell.paymentDate.text = "Due: \(String(describing: UserDefaults.standard.string(forKey: "Date")))"
//            cell.payIcon.image = UIImage(named: "baseline_alarm_blackdue_18dp")
            cell.payIcon.image = data[indexPath.row].payImage
             cell.payNow.isHidden = false
        }
        else{
//            cell.paymentName.text = "Payment \(String(describing: UserDefaults.standard.string(forKey: "pay_amount"))) INR recieved"
//            cell.paymentDetail.text = "For \(String(describing: UserDefaults.standard.string(forKey: "category_group"))) subscription"
//            cell.paymentDate.text = "Date: \(String(describing: UserDefaults.standard.string(forKey: "Date")))"
//            cell.payIcon.image = UIImage(named: "baseline_receipt_black1_18dp")
             cell.payIcon.image = data[indexPath.row].payImage
            cell.payNow.isHidden = true
        }
        
        return cell
        
        
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let str = formatter.string(from: Date())
        loader.showActivityIndicator(uiView: self.view)
        let col = ["pay_amount","balance","date","clear","category_group"]
        let filter = [["date","<=",str],["contact_id","=",UserDefaults.standard.string(forKey: "contact_id")!],["clear","IN",["0","1"]],["park","=","0"]]
        
        let parameter: [String: Any] = ["col": col,"filter": filter]
       
        let d = connectServer.init(ur:"paymentRoute.php?action=select",parameters: parameter,tag: 0)
        d.token = UserDefaults.standard.string(forKey: "token")!
        d.uid = UserDefaults.standard.string(forKey: "user_id")!
        d.bid = UserDefaults.standard.string(forKey: "bid")!
        d.post1()
        d.sendDelegate = self as SendValueDelegate

        
        
        
//        if let items = tabBarController?.tabBar.items {
//            for item in items {
//                item.title = ""
//            }
//        }
//          tabBarItem.title = "Payments"
//        let appearance = UITabBarItem.appearance()
//        let attributes = [NSAttributedString.Key.font:UIFont(name: "Helvetica", size: 16)]
//        appearance.setTitleTextAttributes(attributes as [NSAttributedString.Key : Any], for: .normal)
//
////        for tabBarItem in tabBarController!.tabBar.items!{
////                tabBarItem.title = ""
////        }
//        data = [payment.init(paymentName: "Payment due of 300 INR", paymentDetail: "For Monthly Subscription", paymentDate: "28 Feb 2019", payImage: UIImage(named: "baseline_receipt_black1_18dp")!)]
//
//        data.append(payment(paymentName: "Payment 6500 INR received", paymentDetail: "For Yearly Subscription", paymentDate: "15 Feb 2019", payImage: UIImage(named: "baseline_receipt_black1_18dp")!))
//
//       data.append(payment(paymentName: "Payment 6500 INR received", paymentDetail: "For Monthly Subscription", paymentDate: "01 Feb 2019", payImage: UIImage(named: "baseline_receipt_black1_18dp")!))
//        data.append(payment(paymentName: "Payment 6500 INR received", paymentDetail: "For Monthly Subscription", paymentDate: "01 Feb 2019", payImage: UIImage(named: "baseline_receipt_black1_18dp")!))
//
//        data.append(payment(paymentName: "Payment Received", paymentDetail: "For Monthly Subscription", paymentDate: "01 Feb 2019", payImage: UIImage(named: "baseline_receipt_black1_18dp")!))
        

       titleBar()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
       titleBar()
//        let formatter = DateFormatter()
//        formatter.dateFormat = "yyyy-MM-dd"
//        let str = formatter.string(from: Date())
//
//        let col = ["pay_amount","balance","date","clear","category_group"]
//        let filter = [["date","<=",str],["contact_id","=",UserDefaults.standard.string(forKey: "contact_id")!],["clear","IN",["0","1"]],["park","=","0"]]
//
//        let parameter: [String: Any] = ["col": col,"filter": filter]
//
//        let d = connectServer.init(ur:"paymentRoute.php?action=select",parameters: parameter,tag: 0)
//        d.token = UserDefaults.standard.string(forKey: "token")!
//        d.uid = UserDefaults.standard.string(forKey: "user_id")!
//        d.bid = UserDefaults.standard.string(forKey: "bid")!
//        d.post1()
//        d.sendDelegate = self as SendValueDelegate
        
    }
    
    func titleBar(){
        
        if let items = tabBarController?.tabBar.items {
            for item in items {
                item.title = ""
                item.imageInsets = UIEdgeInsets(top: 0, left: 0, bottom: -10, right: 0)
            }
        }
        tabBarItem.title = "Payments"
        tabBarItem.imageInsets = UIEdgeInsets(top: 0, left: 0, bottom: -45, right: 0)
        
        let appearance = UITabBarItem.appearance()
        let attributes = [NSAttributedString.Key.font:UIFont(name: "Helvetica Bold", size: 15)]
        appearance.setTitleTextAttributes(attributes as [NSAttributedString.Key : Any], for: .normal)
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    var md: [[String:Any]] = [[:]]
    func  getPayment(jsonDic: [String:Any]){

        let data1 = jsonDic["data"] as! [Any]
        md.remove(at: 0)
        for i in data1{
            md.append(i as! [String:Any])
        }
        
        for t in md{
            if t["clear"] as! String == "0"{
                due = true
                UserDefaults.standard.set(t["balance"] as! String, forKey: "balance")
                UserDefaults.standard.set(t["category_group"] as! String, forKey: "category_group")
                UserDefaults.standard.set(t["date"] as! String, forKey: "Date")
                
                let dateY = (t["date"] as! String).components(separatedBy: "-")
                
                let year: String = dateY[0]
                var month: String = dateY[1]
                let date: String = dateY[2]
                month = getMonth(month: month)
                
                data.append(payment(paymentName: "Payment due of \(t["balance"] as! String) INR", paymentDetail: "For \(t["category_group"] as! String) subscription", paymentDate: "Due: \(date)-\(month)-\(year)", payImage: UIImage(named: "baseline_alarm_blackdue_18dp")!))
            }
            else{
                due = false
                UserDefaults.standard.set(t["pay_amount"] as! String, forKey: "pay_amount")
                UserDefaults.standard.set(t["category_group"] as! String, forKey: "category_group")
                UserDefaults.standard.set(t["date"] as! String, forKey: "Date")
                
                let dateY = (t["date"] as! String).components(separatedBy: "-")
                
                let year: String = dateY[0]
                let month: String = dateY[1]
                let date: String = dateY[2]
                
                 data.append(payment(paymentName: "Payment \(t["pay_amount"] as! String) INR recieved", paymentDetail: "For \(t["category_group"] as! String) subscription", paymentDate: "Date: \(date)-\(month)-\(year)", payImage: UIImage(named: "baseline_receipt_black1_18dp")!))
            }
        }
        print(data.count)
        tableView.reloadData()
        loader.hideActivityIndicator(uiView: self.view)
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

    func getMonth(month:String) -> String {
        switch month {
        case "01":
            return "Jan"
        case "02":
            return "Feb"
        case "03":
            return "Mar"
        case "04":
            return "Apr"
        case "05":
            return "May"
        case "06":
            return "Jun"
        case "07":
            return "Jul"
        case "08":
            return "Aug"
        case "09":
            return "Sep"
        case "10":
            return "Oct"
        case "11":
            return "Nov"
        case "12":
            return "Dec"
        default:
            return ""
        }
    }
}
