//
//  PaymentTableViewCell.swift
//  application
//
//  Created by jabeed on 20/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class PaymentTableViewCell: UITableViewCell {
    
    @IBOutlet weak var paymentName: UILabel!
    @IBOutlet weak var paymentDate: UILabel!
    @IBOutlet weak var paymentDetail: UILabel!
    @IBOutlet weak var payIcon: UIImageView!
    @IBOutlet weak var payNow: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
