//
//  BatchSessionsViewController.swift
//  application
//
//  Created by jabeed on 19/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit


extension BatchSessionsViewController: SendValueDelegate{
    
    func send(dic: [String : Any], tag: Int) {
        
        getSessions(jsonDic: dic)
    }
}



@IBDesignable
class DesignableView: UIView {
}

@IBDesignable
class DesignableButton: UIButton {
}

@IBDesignable
class DesignableLabel: UILabel {
}

extension UIView {

    @IBInspectable
    var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
        }
    }

    @IBInspectable
    var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }

    @IBInspectable
    var borderColor: UIColor? {
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.borderColor = color.cgColor
            } else {
                layer.borderColor = nil
            }
        }
    }

    @IBInspectable
    var shadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }

    @IBInspectable
    var shadowOpacity: Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }

    @IBInspectable
    var shadowOffset: CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }

    @IBInspectable
    var shadowColor: UIColor? {
        get {
            if let color = layer.shadowColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.shadowColor = color.cgColor
            } else {
                layer.shadowColor = nil
            }
        }
    }
}

struct sessions {
    let date: String
    let time: String
    let name: String
    let status: String
    var image: UIImage
    let imageLabel: String
}

class BatchSessionsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var sessionBarItem: UITabBarItem!
    @IBOutlet weak var tableView: UITableView!
//    @IBOutlet weak var dialogView: UIView!
    @IBOutlet weak var headerLabel: UILabel!
    
    var loader = ViewControllerUtils()
    
    var data = [sessions]()
    
    var sectionsArray = NSMutableArray()
    var sectionRowDataArray = NSMutableArray()

    func numberOfSections(in tableView: UITableView) -> Int {
        return self.sectionsArray.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let currentSectionRowData = self.sectionRowDataArray[section] as! NSMutableArray
        
       return currentSectionRowData.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let dateString = self.sectionsArray[section] as! String
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-mm-dd"
        let dateObject = formatter.date(from: dateString)!
        formatter.dateFormat = "EEE MMM dd"
        let result = formatter.string(from: dateObject)
        return result
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
          let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BatchCustomSessionTableViewCell
        
        let currentSectionRowData = self.sectionRowDataArray[indexPath.section] as! NSMutableArray
        let currentRowData = currentSectionRowData[indexPath.row] as! [String:Any]
        
        
        
        var start_time = ""
        var end_time = ""
        var category_name = ""
        var sessions_used:Int?
        
        print(currentRowData)
        
        if  let startTime = currentRowData["start_time"] as? String  {
            if startTime.count > 0 {
                let startTime = (currentRowData["start_time"] as! String).components(separatedBy: ":")
                let Shour :String = startTime[0]
                let Smin: String = startTime[1]
                if (Int(Shour)! >= 12) {
                    start_time = "\(Int(Shour)! - 12)" + ":" + Smin + " PM"
                } else {
                    start_time = "\(Int(Shour)!)" + ":" + Smin + " AM"
                }
            }
        }
        
        if let endTime = currentRowData["end_time"] as? String  {
            if (endTime.count > 0) {
                let endDateTime = (currentRowData["end_time"] as! String).components(separatedBy: ":")
                let Shour :String = endDateTime[0]
                let Smin: String = endDateTime[1]
                if (Int(Shour)! >= 12) {
                    end_time = "\(Int(Shour)! - 12)" + ":" + Smin + " PM"
                } else {
                    end_time = "\(Int(Shour)!)" + ":" + Smin + " AM"
                }
            }
        }
        
        if (currentRowData["category"] != nil) {
            category_name = currentRowData["category"] as! String
        }
        
        if (currentRowData["sessions_used"] != nil) {
            if ((currentRowData["sessions_used"] as? NSString)?.intValue) != nil {
                // here, totalfup is a Double
                sessions_used = Int(currentRowData["sessions_used"] as! String)!
            }
            else {
                // dict["totalfup"] isn't a String
                sessions_used = (currentRowData["sessions_used"] as! Int)
            }
        }
        
        cell.startTime?.text = start_time
        cell.endTime?.text = end_time
        cell.category?.text = category_name
        
        if (sessions_used != nil) {
            cell.session?.text = "Session Used-" + "\(String(describing: sessions_used!))"
        }
        if (currentRowData["is_present"] != nil) {
            var is_present:Int?
            if ((currentRowData["is_present"] as? NSString)?.intValue) != nil {
                // here, totalfup is a Double
                is_present = Int(currentRowData["is_present"] as! String)!
            }
            else {
                // dict["totalfup"] isn't a String
                is_present = (currentRowData["is_present"] as! Int)
            }
            
            if (is_present == 0) {
                cell.status.backgroundColor = UIColor.red
            } else if (is_present == 1) {
                cell.status.backgroundColor = UIColor.green
            }
        }
        
        
        if (currentRowData["is_event"] != nil) {
            var is_event:Int?
            if ((currentRowData["is_event"] as? NSString)?.intValue) != nil {
                // here, totalfup is a Double
                is_event = Int(currentRowData["is_event"] as! String)!
            }
            else {
                // dict["totalfup"] isn't a String
                is_event = (currentRowData["is_event"] as! Int)
            }
            
            if (is_event == 1) {
                cell.status.backgroundColor = UIColor.blue
                if (currentRowData["event"] != nil) {
                    cell.category?.text = currentRowData["event"] as? String
                    cell.session?.text = ""
                }
            }
            
        }
        
        if (currentRowData["is_holiday"] != nil) {
            var is_holiday:Int?
            if ((currentRowData["is_holiday"] as? NSString)?.intValue) != nil {
                // here, totalfup is a Double
                is_holiday = Int(currentRowData["is_holiday"] as! String)!
            }
            else {
                // dict["totalfup"] isn't a String
                is_holiday = (currentRowData["is_holiday"] as! Int)
            }
            
            if (is_holiday == 1) {
                cell.status.backgroundColor = UIColor.orange
                if (currentRowData["holiday"] != nil) {
                    cell.category?.text = currentRowData["holiday"] as? String
                    cell.session?.text = ""
                    cell.startTime?.text = "All Day"
                    cell.endTime?.text = ""
                }
            }
            
            
        }
        
        
        
        
            
//            cell.sessionDate.text = data[indexPath.row].date
//            cell.sessionName.text = data[indexPath.row].name
//            cell.sessionTime.text = data[indexPath.row].time
//            cell.sessionStatus.text = data[indexPath.row].status
//
//            if data[indexPath.row].status == "Attended"{
//                data[indexPath.row].image = UIImage(named: "OvalGreen")!
//                cell.cellImage.image = data[indexPath.row].image
//            }
//            else if data[indexPath.row].status == ""{
//                data[indexPath.row].image = UIImage(named: "OvalwH")!
//                cell.cellImage.image = data[indexPath.row].image
//            }
//            else if data[indexPath.row].status == "Missed"{
//                data[indexPath.row].image = UIImage(named: "OvalM")!
//                cell.cellImage.image = data[indexPath.row].image
//            }
//
//            cell.cellImageDateLabel.text = data[indexPath.row].imageLabel
        
        
        // I set the full width  of separator in UITableView
        cell.preservesSuperviewLayoutMargins = false
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
    
            return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let currentSectionRowData = self.sectionRowDataArray[indexPath.section] as! NSMutableArray
        let currentRowData = currentSectionRowData[indexPath.row] as! [String:Any]
        print(currentRowData)
        
        
        if (currentRowData["is_event"] != nil) {
            var is_event:Int?
            if ((currentRowData["is_event"] as? NSString)?.intValue) != nil {
                // here, totalfup is a Double
                is_event = Int(currentRowData["is_event"] as! String)!
            }
            else {
                // dict["totalfup"] isn't a String
                is_event = (currentRowData["is_event"] as! Int)
            }
            
            if (is_event == 1) {
                let presentView = ImageViewController.init(nibName: "ImageViewController", bundle: nil)
                presentView.imageName = currentRowData["image"] as? String
                //Present
                presentView.modalTransitionStyle = .crossDissolve
                presentView.modalPresentationStyle = .overCurrentContext
                self.present(presentView, animated: true, completion: nil)
            }
            
        }
        
        
        
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.dismiss(animated: false, completion: nil)
    }
    
    var md: [[String:Any]] = [[:]]
    var present = false
    
    
    func getSessions(jsonDic: [String:Any]){
        self.createSessionData(sessionDictionary: jsonDic)
        tableView.reloadData()
        loader.hideActivityIndicator(uiView: self.view)
        return
        print(jsonDic["data"])
        let data1 = jsonDic["data"] as! [Any]
        md.remove(at: 0)
        for i in data1{
            md.append(i as! [String:Any])
        }
        print(md)
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let str = formatter.string(from: Date())
        let today = formatter.date(from: str)
        print(formatter)
        for t in md{
            if (t["is_present"] != nil && today != nil && t["date"] != nil) {
                let batchDate = formatter.date(from: t["date"] as! String)!

                var is_present:Int?
                if ((t["is_present"] as? NSString)?.intValue) != nil {
                    // here, totalfup is a Double
                    is_present = Int(t["is_present"] as! String)!
                }
                else {
                    // dict["totalfup"] isn't a String
                    is_present = (t["is_present"] as! Int)
                }
                
                if (is_present == 1 && ((today?.compare(batchDate) == .orderedSame) || (today?.compare(batchDate) == .orderedDescending )) && (t["start_time"] as! String).count > 0 && (t["end_time"] as! String).count > 0 && (t["date"] as! String).count > 0) {
                    present = true

                    let startTime = (t["start_time"] as! String).components(separatedBy: ":")
                    let Shour :String = startTime[0]
                    let Smin: String = startTime[1]
                    
                    let endTime = (t["end_time"] as! String).components(separatedBy: ":")
                    let ehour :String = endTime[0]
                    let emin: String = endTime[1]
                    
                    let dateY = (t["date"] as! String).components(separatedBy: "-")
                    
                    let year: String = dateY[0]
                    var month: String = dateY[1]
                    
                    month = getMonth(month: month)
                    let date: String = dateY[2]
                    
                    data.append(sessions(date: "\(date)-\(month)-\(year)", time: "\(Shour):\(Smin)-\(ehour):\(emin)", name:(t["category"] as! String), status: "Attended", image: UIImage(named: "OvalGreen")!, imageLabel: "\(date)"))
                }
                else if (is_present == 0 && ((today?.compare(batchDate) == .orderedSame) || (today?.compare(batchDate) == .orderedDescending )) && (t["start_time"] as! String).count > 0 && (t["end_time"] as! String).count > 0 && (t["date"] as! String).count > 0) {
                    
                    present = false
                    let startTime = (t["start_time"] as! String).components(separatedBy: ":")
                    let Shour :String = startTime[0]
                    let Smin: String = startTime[1]
                    
                    let endTime = (t["end_time"] as! String).components(separatedBy: ":")
                    let ehour :String = endTime[0]
                    let emin: String = endTime[1]
                    
                    let dateY = (t["date"] as! String).components(separatedBy: "-")
                    
                    let year: String = dateY[0]
                    var month: String = dateY[1]
                    
                    month = getMonth(month: month)
                    let date: String = dateY[2]
                    
                    var sessions_used:Int?
                    if ((t["sessions_used"] as? NSString)?.intValue) != nil {
                        // here, totalfup is a Double
                        sessions_used = Int(t["sessions_used"] as! String)!
                    }
                    else {
                        // dict["totalfup"] isn't a String
                        sessions_used = (t["sessions_used"] as! Int)
                    }
                    
                    data.append(sessions(date: "\(date)-\(month)-\(year)", time: "\(Shour):\(Smin)-\(ehour):\(emin)", name:(t["category"] as! String) + " Session #" + "\( sessions_used!)", status: "Missed", image: UIImage(named: "OvalM")!, imageLabel: "\(date)"))
                } else {
                    if (t["start_time"] != nil && t["end_time"] != nil && t["date"] != nil && (t["start_time"] as! String).count > 0 && (t["end_time"] as! String).count > 0 && (t["date"] as! String).count > 0 ) {
                        let startTime = (t["start_time"] as! String).components(separatedBy: ":")
                        let Shour :String = startTime[0]
                        let Smin: String = startTime[1]
                        
                        let endTime = (t["end_time"] as! String).components(separatedBy: ":")
                        let ehour :String = endTime[0]
                        let emin: String = endTime[1]
                        
                        let dateY = (t["date"] as! String).components(separatedBy: "-")
                        
                        let year: String = dateY[0]
                        var month: String = dateY[1]
                        
                        month = getMonth(month: month)
                        let date: String = dateY[2]
                        
                        var sessions_used:Int?
                        if ((t["sessions_used"] as? NSString)?.intValue) != nil {
                            // here, totalfup is a Double
                            sessions_used = Int(t["sessions_used"] as! String)!
                        }
                        else {
                            // dict["totalfup"] isn't a String
                            sessions_used = (t["sessions_used"] as! Int)
                        }
                        
                        data.append(sessions(date: "\(date)-\(month)-\(year)", time: "\(Shour):\(Smin)-\(ehour):\(emin)", name: (t["category"] as! String) + " Session #" + "\(sessions_used!)", status: "", image: UIImage(named: "OvalwH")!, imageLabel: "\(date)"))
                    }
                }
               
            
            } else {
                if (t["start_time"] != nil && t["end_time"] != nil && t["date"] != nil && (t["start_time"] as! String).count > 0 && (t["end_time"] as! String).count > 0 && (t["date"] as! String).count > 0 ) {
                    let startTime = (t["start_time"] as! String).components(separatedBy: ":")
                    let Shour :String = startTime[0]
                    let Smin: String = startTime[1]
                    
                    let endTime = (t["end_time"] as! String).components(separatedBy: ":")
                    let ehour :String = endTime[0]
                    let emin: String = endTime[1]
                    
                    let dateY = (t["date"] as! String).components(separatedBy: "-")
                    
                    let year: String = dateY[0]
                    var month: String = dateY[1]
                    
                    month = getMonth(month: month)
                    let date: String = dateY[2]
                    
                    var sessions_used:Int?
                    if ((t["sessions_used"] as? NSString)?.intValue) != nil {
                        // here, totalfup is a Double
                        sessions_used = Int(t["sessions_used"] as! String)!
                    }
                    else {
                        // dict["totalfup"] isn't a String
                        sessions_used = (t["sessions_used"] as! Int)
                    }
                    
                    data.append(sessions(date: "\(date)-\(month)-\(year)", time: "\(Shour):\(Smin)-\(ehour):\(emin)", name: (t["category"] as! String) + " Session #" + "\(sessions_used!)", status: "", image: UIImage(named: "OvalwH")!, imageLabel: "\(date)"))
                }
            }
        }
        print(data.count)
        tableView.reloadData()
        loader.hideActivityIndicator(uiView: self.view)
        
        
    }
    
    
    func createSessionData(sessionDictionary: [String:Any]) {
        var md: [[String:Any]] = [[:]]
        md.remove(at: 0)
        let sessionDataArray = sessionDictionary["data"] as! [Any]
        print(sessionDataArray)

        for i in sessionDataArray{
            md.append(i as! [String:Any])
        }
        
        for sessionItem in md {
            print(sessionItem)
            let itemDate = sessionItem["date"] as! String
            if (sectionsArray.count == 0) {
                sectionsArray.add(itemDate)
            } else {
                if (!sectionsArray.contains(itemDate)) {
                    sectionsArray.add(itemDate)
                }
            }
            
        }
        
        print(sectionsArray)
        
        for sectionDate in sectionsArray {
            let rowData = NSMutableArray()
//            let formatter = DateFormatter()
//            formatter.dateFormat = "EEE MMM DD"
//            let result = formatter.string(from:  Date)
//            print(result)
            for sessionItem in md {
                let itemDate = sessionItem["date"] as! NSString
                if (itemDate.isEqual(sectionDate) ) {
                    
                    if let startTime = sessionItem["start_time"], let endTime = sessionItem["end_time"] {
                         rowData.add(sessionItem)
                        
                    }
//                    if (sessionItem["start_time"] != nil && (sessionItem["start_time"] as! String).count > 0 && sessionItem["end_time"] != nil && (sessionItem["end_time"] as! String).count > 0) {
//
//                    }
                    
                }
            }
            sectionRowDataArray.add(rowData)
        }
        
        print(sectionRowDataArray)
    }

    override func viewDidLoad() {
       // self.tableView.separatorColor = UIColor.darkGray

        super.viewDidLoad()
    
    
//        data = [sessions.init(date: "04 June 2019", time: "09:00 - 10:30", name: "ABCD Sessions #3" , status: "Attended",image: UIImage(named: "OvalwH")!, imageLabel: "04" )]
//        data.append(sessions(date: "16 June 2019", time: "09:00 - 10:30", name: "ABCD Sessions #4" , status: "",image: UIImage(named: "OvalwH")!, imageLabel: "16"))
//         data.append(sessions(date: "21 June 2019", time: "09:00 - 10:30", name: "ABCD Sessions #5" , status: "Missed",image: UIImage(named: "OvalwH")!, imageLabel: "21"))
//         data.append(sessions(date: "22 June 2019", time: "09:00 - 10:30", name: "ABCD Sessions #6" , status: "",image: UIImage(named: "OvalwH")!, imageLabel: "22"))
//         data.append(sessions(date: "28 June 2019", time: "09:00 - 10:30", name: "ABCD Sessions #7" , status: "",image: UIImage(named: "OvalwH")!, imageLabel: "28"))
//
//        data.append(sessions(date: "29 June 2019", time: "09:00 - 10:30", name: "ABCD Sessions #8" , status: "",image: UIImage(named: "OvalwH")!, imageLabel: "29"))

               // items![0] index of your tab bar item.items![0] means tabbar first item
        loader.showActivityIndicator(uiView: self.view)
        

   //     let col = ["category","service","start_date","end_date","sessions_used","sessions"]
//        let filter = [["contact_id","=",UserDefaults.standard.string(forKey: "contact_id")!]]
//        let parameter: [String: Any] = ["col": col,"filter": filter]
//        let col = ["contact_id":UserDefaults.standard.string(forKey: "contact_id")!]
        let parameter: [String: Any] = ["contact_id":UserDefaults.standard.string(forKey: "contact_id")!]
        let d = connectServer.init(ur:"attendanceRoute.php?action=selectBatchSessionAtt",parameters: parameter,tag: 0)
        d.token = UserDefaults.standard.string(forKey: "token")!
        d.uid = UserDefaults.standard.string(forKey: "user_id")!
        d.bid = UserDefaults.standard.string(forKey: "bid")!
        d.post1()
        d.sendDelegate = self as SendValueDelegate
        
        
//    tabBarItem.title = "Sessions"
//    let appearance = UITabBarItem.appearance()
//        let attributes = [NSAttributedString.Key.font:UIFont(name: "Helvetica", size: 16)]
//        appearance.setTitleTextAttributes(attributes as [NSAttributedString.Key : Any], for: .normal)
//
//    tableView.reloadData()
        // Do any additional setup after loading the view.
    
      titleBar()
    }
    
    override func viewDidAppear(_ animated: Bool) {
      titleBar()
    }
    func titleBar(){
        
        if let items = tabBarController?.tabBar.items {
            for item in items {
                item.title = ""
                item.imageInsets = UIEdgeInsets(top: 0, left: 0, bottom: -10, right: 0)
        }
        }
        tabBarItem.title = "Sessions"
        tabBarItem.imageInsets = UIEdgeInsets(top: 0, left: 0, bottom: -45, right: 0)
        
        let appearance = UITabBarItem.appearance()
        let attributes = [NSAttributedString.Key.font:UIFont(name: "Helvetica Bold", size: 15)]
        appearance.setTitleTextAttributes(attributes as [NSAttributedString.Key : Any], for: .normal)
        
    }
    func getMonth(month:String) -> String {
        switch month {
        case "01":
            return "Jan"
        case "02":
            return "Feb"
        case "03":
            return "Mar"
        case "04":
            return "Apr"
        case "05":
            return "May"
        case "06":
            return "Jun"
        case "07":
            return "Jul"
        case "08":
            return "Aug"
        case "09":
            return "Sep"
        case "10":
            return "Oct"
        case "11":
            return "Nov"
        case "12":
            return "Dec"
        default:
            return ""
        }
    }
        
    
    
}
