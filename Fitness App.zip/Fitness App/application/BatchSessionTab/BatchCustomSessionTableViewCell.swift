//
//  BatchCustomSessionTableViewCell.swift
//  application
//
//  Created by jabeed on 14/09/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class BatchCustomSessionTableViewCell: UITableViewCell {

    
    @IBOutlet weak var startTime: UILabel!
    @IBOutlet weak var endTime: UILabel!
    
    @IBOutlet weak var status: UILabel!
    
    @IBOutlet weak var category: UILabel!
    
    @IBOutlet weak var session: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
