//
//  BatchSessionTableViewCell.swift
//  application
//
//  Created by jabeed on 19/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit


class BatchSessionTableViewCell: UITableViewCell {

    
    @IBOutlet weak var sessionDate: UILabel!
    @IBOutlet weak var sessionTime: UILabel!
    @IBOutlet weak var sessionName: UILabel!
    @IBOutlet weak var sessionStatus: UILabel!
    @IBOutlet weak var cellImage: UIImageView!
    @IBOutlet weak var cellImageDateLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
