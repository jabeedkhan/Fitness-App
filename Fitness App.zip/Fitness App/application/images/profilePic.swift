//
//  profile.swift
//  application
//
//  Created by jabeed on 16/07/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import Foundation
import UIKit

class profilePic{
    
    static var compressedImage: UIImage = UIImage()
    static var imageURL: URL = URL(fileURLWithPath: "")
    static var imagePath = ""
    static var imageData = Data()
    static var imageChosed = false
    static var loadedImage: UIImage = UIImage()
}

