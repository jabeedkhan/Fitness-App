//
//  TabBarViewController.swift
//  application
//
//  Created by jabeed on 20/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class TabBarViewController: UITabBarController {

    var defaults = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()

        tabBar.tintColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    
        for tabBarItem in tabBar.items!{
            tabBarItem.titlePositionAdjustment = UIOffset(horizontal: 0, vertical: -24)
            tabBarItem.title = ""
        }
        
          let profile : ProfileViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "profile") as! ProfileViewController
        
  
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
