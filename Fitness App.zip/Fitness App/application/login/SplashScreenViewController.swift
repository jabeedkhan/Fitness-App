//
//  SplashScreenViewController.swift
//  application
//
//  Created by jabeed on 23/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

extension SplashScreenViewController: SendValueDelegate{
    func send(dic: [String : Any], tag: Int) {
        self.jsonDict = dic
        
        access(jsonDict: dic)
    }

    
}

class SplashScreenViewController: UIViewController {

     var jsonDict: [String:Any] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let token = UserDefaults.standard.string(forKey: "token")
        
        let parameter: [String: Any] = ["user_type":"M"]
        let d = connectServer.init(ur:"registrationRoute.php?action=getUserSettings",parameters: parameter,tag: 0)
        d.token = token!
        d.uid = UserDefaults.standard.string(forKey: "user_id")!
        d.bid = UserDefaults.standard.string(forKey: "bid")!
        d.post1()
        d.sendDelegate = self as SendValueDelegate
    
        Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(timeOut), userInfo: nil, repeats: false)

        // Do any additional setup after loading the view.
    }
    
    func access(jsonDict: [String: Any]){
       
//        print(jsonDict)
        let data = jsonDict["data"] as?  [String: Any]
        UserDefaults.standard.setValue(data!["token"], forKey: "token")
        print("SplashScreen",UserDefaults.standard.string(forKey: "token")!)
    }
    
    @objc func timeOut(){
    
        let SignedIn : TabBarViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "signedIn") as! TabBarViewController
//        let transition = CATransition()
//        transition.duration = 0.5
//        transition.type = CATransitionType.push
//        transition.subtype = CATransitionSubtype.fromRight
//        transition.timingFunction = CAMediaTimingFunction(name:CAMediaTimingFunctionName.easeInEaseOut)
//        view.window!.layer.add(transition, forKey: kCATransition)
//        present(SignedIn, animated: true, completion: nil)
        self.navigationController?.pushViewController(SignedIn, animated: true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
