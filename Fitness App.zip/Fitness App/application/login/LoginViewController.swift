//
//  ViewController.swift
//  loginPage
//
//  Created by jabeed on 13/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit
import GoogleSignIn
import FBSDKLoginKit

extension LoginViewController: SendValueDelegate{
    
    func send(dic: [String : Any],tag: Int) {
    
        self.jsonDict = dic
        
        switch tag {
        case LoginViewController.LOGIN_REQUEST:
             print("\nLOGIN BUTTON")
             print("--------------------------------------")
             get(jsonDict: jsonDict)
             print("--------------------------------------")
            
        case LoginViewController.FORGOT_PASSWORD_REQUEST:
             print("\nFORGOT PASSWORD BUTTON")
             print("--------------------------------------")
             get(jsonDict: jsonDict)
             print("--------------------------------------")
            
        case LoginViewController.FACEBOOK_LOGIN_REQUEST:
             print("\nFACEBOOK BUTTON")
             print("--------------------------------------")
             validateFacebookSignIn(jsonDict: jsonDict)
             print("--------------------------------------")
            
        case LoginViewController.GOOGLE_LOGIN_REQUEST:
             print("\nLGOOGLE BUTTON")
             print("--------------------------------------")
             validateGoogleSignIn(jsonDict: jsonDict)
             print("--------------------------------------")
            
        default:
             print("Internal Error")
        }
        
    }
}


class LoginViewController: UIViewController,GIDSignInDelegate,LoginButtonDelegate {
    
    
    @IBOutlet weak var mobileTextField: UITextField!
    @IBOutlet weak var fbutton: UIButton!
    @IBOutlet weak var passTextField: UITextField!
    @IBOutlet weak var gbutton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var forgotPassButton: UIButton!
    
    @IBOutlet weak var upperView: UIView!
    
    @IBOutlet weak var lowerView: UIView!
    @IBOutlet var mainView: UIView!
    static let LOGIN_REQUEST = 0
    static let FORGOT_PASSWORD_REQUEST = 1
    static let FACEBOOK_LOGIN_REQUEST = 2
    static let GOOGLE_LOGIN_REQUEST = 3
    
    let defaults = UserDefaults.standard
    var jsonDict: [String:Any] = [:]
    var name:String = ""
    var email:String = ""
    var id:String = ""
    
    var fname:String = ""
    var femail:String = ""
    var fid:String = ""
   
    var blurEffect = UIBlurEffect()
    var blurEffectView = UIVisualEffectView()
    
    let loadingView =  ViewControllerUtils()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        buttonShadow(button: fbutton)
        buttonShadow(button: gbutton)

         drawLine(startX: Int(lowerView.frame.origin.x), toEndingX: Int(lowerView.frame.width), startingY: Int(lowerView.frame.origin.y), toEndingY:  Int(lowerView.frame.origin.y+1) , ofColor: #colorLiteral(red: 0.6000000238, green: 0.6000000238, blue: 0.6000000238, alpha: 1), widthOfLine: 1.0, inView: self.view)
        
        self.hideKeyboardWhenTappedAround()
    }
    @IBAction func googleSignIn(_ sender: Any) {
        
        GIDSignIn.sharedInstance().delegate=self
       // GIDSignIn.sharedInstance().uiDelegate=self / / this is not framework in google (GIDSignInUIDelegate)
        GIDSignIn.sharedInstance().signIn()
    }
    
   func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        
        if let error = error {
            print("\(error.localizedDescription)")
        }
        else {
            // Perform any operations on signed in user here.
            id = user.userID!
            email =  user.profile.email!
            name = user.profile.name!
            let parameter: [String: Any] = ["email": email ,"id": id,"name":name,"login":"1","type":"google","user_type":"m"]
            
            let valiOAuth = connectServer.init(ur:"registrationRoute.php?action=validateOauth",parameters: parameter,tag: 3)
            valiOAuth.posts()
            valiOAuth.sendDelegate = self as SendValueDelegate
    }
            GIDSignIn.sharedInstance()?.signOut()
    }
    
    
    func validateGoogleSignIn(jsonDict: [String: Any]){
        print(jsonDict)
        let e:Int = jsonDict["error"] as! Int
        if e == 0 {
            
            let validOAuth : ValidateOAuthViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "validOauth") as! ValidateOAuthViewController
            validOAuth.name = name
            validOAuth.email = email
            validOAuth.id = id
            self.present(validOAuth, animated: true, completion: nil)
//            performSegue(withIdentifier: "validateOAuth", sender: self)
        }
        else{
            let alreadySigned : AlreadySignInViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "alreadySigned") as! AlreadySignInViewController
            
            alreadySigned.username = email
            alreadySigned.name = name
            alreadySigned.id = id
            self.present(alreadySigned, animated: true, completion: nil)
            
        }
    }

    @IBAction func loginFacebook(_ sender: Any) {
        
        let fbLoginManager : LoginManager = LoginManager()
        
        fbLoginManager.logIn(permissions: ["public_profile","email"], from: self) { (result, error) in
            if (error == nil){
                let fbloginresult : LoginManagerLoginResult = result!
                // if user cancel the login
                if (result?.isCancelled)!{
                    return
                }
                if(fbloginresult.grantedPermissions.contains("email"))
                {
                    self.getFBUserData()
                    if AccessToken.current != nil {
                        let logout = LoginManager()
                        logout.logOut()
                    }
                }
            }
        }
    }
    
    func getFBUserData(){
        if AccessToken.current != nil {
            
            let req = GraphRequest(graphPath: "me", parameters: ["fields":"email,name,gender,id,link"], tokenString: AccessToken.current?.tokenString, version: nil, httpMethod: HTTPMethod(rawValue: "GET"))
            req.start { (connection: GraphRequestConnection?, result: Any?, error: Error?) in
                if error != nil
                {
                    print("error \(String(describing: error))")
                }
                else
                {
                    let data:[String:AnyObject] = result as! [String: AnyObject]
                    for (key,value) in data {
                        print("\(key): \(value)")
                    }
                    self.fid = data["id"] as! String
                    self.femail = data["email"] as! String
                    self.fname = data["name"] as! String
                    let parameter: [String: Any] = ["email": self.femail ,"id": self.fid,"name":self.fname,"login":"1","type":"facebook","user_type":"m"]
                    
                    let valiOAuth = connectServer.init(ur:"registrationRoute.php?action=validateOauth",parameters: parameter,tag: 2)
                    valiOAuth.posts()
                    valiOAuth.sendDelegate = self as SendValueDelegate
                }
            }
        }
    }
    
    func validateFacebookSignIn(jsonDict: [String: Any]){
        
        print(jsonDict)
        let e:Int = jsonDict["error"] as! Int
        if e == 0 {
            let validOAuth : ValidateOAuthViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "validOauth") as! ValidateOAuthViewController
            validOAuth.name = fname
            validOAuth.email = femail
            validOAuth.id = fid
            self.present(validOAuth, animated: true, completion: nil)
            //          performSegue(withIdentifier: "validateOAuth", sender: self)
        }
        else{
            let alreadySigned : AlreadySignInViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "alreadySigned") as! AlreadySignInViewController
            alreadySigned.username = femail
            alreadySigned.name = fname
            alreadySigned.id = fid
            self.present(alreadySigned, animated: true, completion: nil)
        }
    }
    
    func loginButton(_ loginButton: FBLoginButton, didCompleteWith result: LoginManagerLoginResult?, error: Error?) {
        //
    }
    
    func loginButtonDidLogOut(_ loginButton: FBLoginButton) {
        //
    }
    
   
    @IBAction func loginTapped(_ sender: Any) {
        
        let mobile = mobileTextField.text
        let pass = passTextField.text
//        blurEffect
//            = UIBlurEffect(style: .dark) // .extraLight or .dark
//        blurEffectView = UIVisualEffectView(effect: blurEffect)
//        blurEffectView.frame = assistView.frame
//        view.addSubview(blurEffectView)
//        view.addSubview(loading)
//        loading.isHidden = false
//        loading.startAnimating()
        loadingView.showActivityIndicator(uiView: self.view)
        if isValid(mobile: mobile!, pass: pass!){
            loadingView.hideActivityIndicator(uiView: self.view)
             displayAlert(userMessage: "Enter username and password")
        }
        else{
            if isNumeric(a: mobile!){
                if mobile!.starts(with: "6") || mobile!.starts(with: "7") || mobile!.starts(with: "8") || mobile!.starts(with: "9")
                {
                    if mobile!.count == 10 {
                        UserDefaults.standard.set(mobile, forKey: "login_user")
                        UserDefaults.standard.set(pass, forKey: "login_password")
                        postp(mobile: mobile!, pass: pass!,tag: LoginViewController.LOGIN_REQUEST)
                        
                    }
                    else{
                        loadingView.hideActivityIndicator(uiView: self.view)
                        displayAlert(userMessage: "Invalid number")
                    }
                }
                else{
                    loadingView.hideActivityIndicator(uiView: self.view)
                    displayAlert(userMessage: "Invalid number")
                }
            }
            else{
                if isValidEmailAddress(emailAddressString: mobile!)
                {
                postp(mobile: mobile!, pass: pass!,tag: LoginViewController.LOGIN_REQUEST)
                }
            else{
                loadingView.hideActivityIndicator(uiView: self.view)
                 displayAlert(userMessage: "Enter valid email")
                }
            }
        }
        mobileTextField.text = ""
        passTextField.text = ""
        
    }
    
    func postp(mobile: String,pass:String,tag: Int){
        
        let parameter: [String: Any] = ["password": pass,"username": mobile]
        let d = connectServer.init(ur:"registrationRoute.php?action=checkCredentials",parameters: parameter,tag: tag)
        d.posts()
        d.sendDelegate = self as SendValueDelegate
    }
    
    var correctCredential = false
    func get(jsonDict: [String:Any])  {
        
        if jsonDict["error"]  as! Int == 1 {
            let message =  jsonDict["message"] as! String
            self.displayAlert(userMessage: message)
            loadingView.hideActivityIndicator(uiView: self.view)
        }
        else if jsonDict["error"] as! Int == 0{
            
//            blurEffect
//                = UIBlurEffect(style: .dark) // .extraLight or .dark
//            blurEffectView = UIVisualEffectView(effect: blurEffect)
//            blurEffectView.frame = assistView.frame
//            view.addSubview(blurEffectView)
//            view.addSubview(loading)
//            loading.isHidden = false
//            loading.startAnimating()
//            let alert = UIAlertController(title: nil, message: "Please wait...", preferredStyle: .alert)
//            let loadingIndicator = UIActivityIndicatorView(frame: CGRect(x: 10, y: 5, width: 50, height: 50))
//            loadingIndicator.style = UIActivityIndicatorView.Style.gray
//            loadingIndicator.startAnimating()
//            alert.view.addSubview(loadingIndicator)
//            present(alert, animated: true, completion: nil)
        
            let data = jsonDict["data"] as?  [String: Any]
            print(data)
            UserDefaults.standard.set(data!["token"], forKey: "token")
           UserDefaults.standard.set(data!["client_id"], forKey: "client_id")
            UserDefaults.standard.set(data!["bid"], forKey: "bid")
           UserDefaults.standard.set(data!["user_id"], forKey: "user_id")
            UserDefaults.standard.set(data!["contact_id"], forKey: "contact_id")
            UserDefaults.standard.set(data!["user_name"], forKey: "name")
           UserDefaults.standard.set(data!["email"], forKey: "email")
            UserDefaults.standard.set(data!["mobile"], forKey: "number")
           UserDefaults.standard.set(data!["user_image"], forKey: "profilePic")
            UserDefaults.standard.synchronize()
            
            let name =  data!["user_name"]
            if name != nil{
                
                correctCredential = true
            
                let splash : SplashScreenViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "splashScreen") as! SplashScreenViewController
                loadingView.hideActivityIndicator(uiView: self.view)
                self.navigationController?.pushViewController(splash, animated: true)
            }
            else{
                loadingView.hideActivityIndicator(uiView: self.view)
                self.displayAlert(userMessage: "Internal Error, Contact Admin")
            }
            for (key, value) in UserDefaults.standard.dictionaryRepresentation() {
                print("\(key) = \(value) \n")
            }
        }
    }
    
    
    override func viewDidLayoutSubviews() {
        setBorder(textField: mobileTextField)
        setBorder(textField: passTextField)
    }
    
    func setBorder(textField: UITextField){
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor.lightGray.cgColor
        border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width, height: textField.frame.size.height)
        border.borderWidth = width
        textField.layer.addSublayer(border)
        textField.layer.masksToBounds = true
    }
    
    func isValid(mobile: String,pass: String)->Bool{
        
        var valid = false
        if mobile.isEmpty || pass.isEmpty{
            valid = true
        }
        return valid
    }
    
    func buttonShadow(button: UIButton){
        button.layer.shadowColor = UIColor.lightGray.cgColor
        button.layer.shadowOffset = CGSize(width: 5, height: 5)
        button.layer.shadowRadius = 5
        button.layer.shadowOpacity = 1.0
    }

    func displayAlert(userMessage: String) {
        
        let myAlert = UIAlertController(title: userMessage, message: "" , preferredStyle: UIAlertController.Style.alert)
        let okAction: UIAlertAction!
        okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        myAlert.addAction(okAction)
        self.present(myAlert, animated: true, completion: nil)
    }
    
    func isNumeric(a: String) -> Bool {
        return Double(a) != nil
    }
    
    func isValidEmailAddress(emailAddressString: String) -> Bool {
        
        var returnValue = true
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        
        do {
            let regex = try NSRegularExpression(pattern: emailRegEx)
            let nsString = emailAddressString as NSString
            let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
            if results.count == 0
            {
                returnValue = false
            }
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            returnValue = false
        }
        return  returnValue
    }
    
    func drawLine(startX: Int, toEndingX endX: Int, startingY startY: Int, toEndingY endY: Int, ofColor lineColor: UIColor, widthOfLine lineWidth: CGFloat, inView view: UIView) {
        
        let path = UIBezierPath()
        path.move(to: CGPoint(x: startX, y: startY))
        path.addLine(to: CGPoint(x: endX, y: endY))
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.strokeColor = lineColor.cgColor
        shapeLayer.lineWidth = lineWidth
        
        view.layer.addSublayer(shapeLayer)
    }
    

    
    
}
