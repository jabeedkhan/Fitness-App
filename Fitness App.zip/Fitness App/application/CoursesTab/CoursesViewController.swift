//
//  CoursesViewController.swift
//  
//
//  Created by pratyush sharma on 21/06/19.
//

import UIKit

extension CoursesViewController: SendValueDelegate{
    
    func send(dic: [String : Any], tag: Int) {
        
        getCourses(jsonDic: dic)
    }
}

struct courses {
    var name: String
    var duration: String
    var dates: String
    var sessions: String
}

class CoursesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    var data = [courses]()
    var loader = ViewControllerUtils()
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CoursesTableViewCell
        
        cell.courseName.text = data[indexPath.row].name
        cell.courseDuration.text = data[indexPath.row].duration
        cell.courseDates.text = data[indexPath.row].dates
        cell.sessions.text = data[indexPath.row].sessions
        
        
        return cell
    }
    

    @IBAction func backButton(_ sender: Any) {
        
         performSegue(withIdentifier : "unwind", sender: self)
        
        
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        loader.showActivityIndicator(uiView: self.view)
//        data = [courses(name: "DSOP6M - Regular", duration: "6 Months Diploma in Sketching & Oil Painting", dates: "04 June 19 - 03 Apr 19", sessions: "12 / 48 Sessions Consumed")]
//
//        data.append(courses(name: "DSOP3M - Regular", duration: "3 Months Diploma in Sketching & Oil Painting", dates: "01 Feb 19 - 30 Apr 19", sessions: "24 / 24 Sessions Consumed"))
        
             let col = ["category","service","start_date","end_date","sessions_used","sessions"]
                let filter = [["contact_id","=",UserDefaults.standard.string(forKey: "contact_id")!]]
                let parameter: [String: Any] = ["col": col,"filter": filter]
           // let col = ["contact_id":UserDefaults.standard.string(forKey: "contact_id")!]
//        let parameter: [String: Any] = ["contact_id":UserDefaults.standard.string(forKey: "contact_id")!]
        let d = connectServer.init(ur:"invoiceRoute.php?action=select",parameters: parameter,tag: 0)
        d.token = UserDefaults.standard.string(forKey: "token")!
        d.uid = UserDefaults.standard.string(forKey: "user_id")!
        d.bid = UserDefaults.standard.string(forKey: "bid")!
        d.post1()
        d.sendDelegate = self as SendValueDelegate
        
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var tableVIew: UITableView!
    var md: [[String:Any]] = [[:]]
    var md2: [[String:Any]] = [[:]]
    func getCourses(jsonDic: [String:Any]){
        
        let data1 = jsonDic["data"] as! [Any]
//        let d = data1["invoice_item"] as! [Any]
//        print(d)
//        print(data1["invoice_item"] as! [String])
        md.remove(at: 0)
        for i in data1{
            md.append(i as! [String : Any])
            }
        
        let md1 = md.first! as [String:Any]
        let m = md1["invoice_item"] as! [Any]
        
        md2.remove(at: 0)
        for j in m{
             md2.append(j as! [String : Any])
        }
        
        var startDate: [String] = []
        var syear: String = ""
        var smonth: String = ""
        var sdate: String = ""
        
        var endDate: [String] = []
        var eyear: String = ""
        var emonth: String = ""
        var edate: String = ""
        
        for t in md2{
            print(t)
                 startDate = (t["start_date"] as! String).components(separatedBy: "-")
                 syear = startDate[0]
                 smonth = startDate[1]
                 sdate = startDate[2]

                endDate = (t["end_date"] as! String).components(separatedBy: "-")
                eyear = endDate[0]
                emonth = endDate[1]
                edate = endDate[2]
           
            print(String(Int(emonth)! - Int(smonth)!))
            var sessionDetail = ""
            
                if (Int(emonth)! - Int(smonth)!) > 1 {
                    sessionDetail = String(Int(emonth)! - Int(smonth)!) + " Months in " + (t["category"] as! String)
                }
                else if (Int(emonth)! - Int(smonth)!) == 1{
                    sessionDetail = String(Int(emonth)! - Int(smonth)!) + " Month in " + (t["category"] as! String)
                }

            smonth = getMonth(month: smonth)
            emonth = getMonth(month: emonth)
            let date = "\(sdate) \(smonth) \(syear) - \(edate) \(emonth) \(eyear)"
            var sessionConsumed = ""
                sessionConsumed = "\(t["sessions_used"] as! String)/\(t["sessions"] as! String) Sessions Consumed"
            
            var service = ""
                 service = t["category"] as! String
           
            data.append(courses(name: service, duration: sessionDetail, dates: date, sessions: sessionConsumed))
        }
        
        
        
        tableVIew.reloadData()
        loader.hideActivityIndicator(uiView: self.view)
}
    func getMonth(month:String) -> String {
        switch month {
        case "01":
            return "Jan"
        case "02":
            return "Feb"
        case "03":
            return "Mar"
        case "04":
            return "Apr"
        case "05":
            return "May"
        case "06":
            return "Jun"
        case "07":
            return "Jul"
        case "08":
            return "Aug"
        case "09":
            return "Sep"
        case "10":
            return "Oct"
        case "11":
            return "Nov"
        case "12":
            return "Dec"
        default:
            return ""
        }
    }
    
    
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
