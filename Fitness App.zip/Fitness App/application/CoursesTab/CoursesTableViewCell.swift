//
//  CoursesTableViewCell.swift
//  application
//
//  Created by jabeed on 21/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class CoursesTableViewCell: UITableViewCell {

    @IBOutlet weak var courseName: UILabel!
    
    @IBOutlet weak var courseDuration: UILabel!
    
    @IBOutlet weak var sessions: UILabel!
    
    @IBOutlet weak var courseDates: UILabel!
    
    @IBOutlet weak var courseIcon: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
