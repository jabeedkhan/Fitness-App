//
//  CustomCellUpper.swift
//  application
//
//  Created by jabeed on 21/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit


extension UITextField {
    func isError(baseColor: CGColor, numberOfShakes shakes: Float, revert: Bool) {
        let animation: CABasicAnimation = CABasicAnimation(keyPath: "shadowColor")
        animation.fromValue = baseColor
        animation.toValue = UIColor.red.cgColor
        animation.duration = 0.4
        if revert { animation.autoreverses = true } else { animation.autoreverses = false }
        self.layer.add(animation, forKey: "")
        
        let shake: CABasicAnimation = CABasicAnimation(keyPath: "position")
        shake.duration = 0.07
        shake.repeatCount = shakes
        if revert { shake.autoreverses = true  } else { shake.autoreverses = false }
        shake.fromValue = NSValue(cgPoint: CGPoint(x: self.center.x - 10, y: self.center.y))
        shake.toValue = NSValue(cgPoint: CGPoint(x: self.center.x + 10, y: self.center.y))
        self.layer.add(shake, forKey: "position")
    }
}



class CustomCell: UITableViewCell{
   

    @IBOutlet weak var mgender: UIButton!
    @IBOutlet weak var fgender: UIButton!

    @IBOutlet weak var map: UIImageView!
    @IBOutlet weak var address: UITextView!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var number: UITextField!
    @IBOutlet weak var mail: UITextField!
    
    @IBOutlet weak var birthday: UITextField!
    @IBOutlet weak var person: UIImageView!
    @IBOutlet weak var phone: UIImageView!
    @IBOutlet weak var cake: UIImageView!
    @IBOutlet weak var email: UIImageView!
    
    @IBOutlet weak var profilePic: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    @IBAction func radioButton(_ sender: UIButton) {
        
        
        if sender.tag == 1{
            print("female")
            
        }
        else if sender.tag == 2{
            print("male")
        }
    }
    @IBAction func selectPic(_ sender: Any) {

//        let d = EditProfileViewController()
//        d.pickImage()
        print("pick")
    }
    
    func setBorderToTextViewColor(textView: UITextView,color: CGColor){
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = color
        border.frame = CGRect(x: 0, y: textView.frame.size.height - width, width: textView.frame.size.width, height: textView.frame.size.height)
        border.borderWidth = width
        textView.layer.addSublayer(border)
        textView.layer.masksToBounds = true
    }

    
    @IBAction func nameEditing(_ sender: Any) {
        
        person.image = UIImage(named: "baseline_person_orange_18dp")
        setBorder(textField: name,color: #colorLiteral(red: 1, green: 0.5502320528, blue: 0, alpha: 1))
        setBorder(textField: number, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        setBorder(textField: birthday, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        setBorder(textField: mail, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
         map.image = UIImage(named: "map-black")
        setBorderToTextViewColor(textView: address, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        phone.image = UIImage(named: "baseline_phone_black_18dp")
        email.image = UIImage(named: "baseline_email_black_18dp")
        cake.image = UIImage(named: "baseline_cake_black_18dp")
    
        
    }
    
    var numberValid = false
    var emailValid = false
    func setBorder(textField: UITextField,color: UIColor){
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = color.cgColor
        border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width, height: textField.frame.size.height)
        border.borderWidth = width
        textField.layer.addSublayer(border)
        textField.layer.masksToBounds = true
    }
    
    @IBAction func phoneEditing(_ sender: Any) {
        
        person.image = UIImage(named: "baseline_person_black_18dpProfile")
        email.image = UIImage(named: "baseline_email_black_18dp")
        cake.image = UIImage(named: "baseline_cake_black_18dp")
        phone.image = UIImage(named: "baseline_phone_orange_18dp")
        setBorder(textField: name, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        setBorder(textField: number, color: #colorLiteral(red: 1, green: 0.5502320528, blue: 0, alpha: 1))
        setBorder(textField: birthday, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        setBorder(textField: mail, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
         map.image = UIImage(named: "map-black")
        setBorderToTextViewColor(textView: address, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        
//        if isValidNumber(num: number.text!) {
//            numberValid = true
//        }else{
//            numberValid = false
////            number.isError(baseColor: #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1), numberOfShakes: 2, revert: true)
//        }
    }
    
    func isValidNumber(num: String) -> Bool {
        
        var returnValue = true
        let numRegEx = "[9|8|7|6][0-9]{9}"
        //         let numRegEx = "\\A[0-9]{8}\\z"
        
        do {
            let regex = try NSRegularExpression(pattern: numRegEx)
            let nsString = num as NSString
            let results = regex.matches(in: num, range: NSRange(location: 0, length: nsString.length))
            if results.count == 0
            {
                returnValue = false
            }
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            returnValue = false
        }
        return  returnValue
    }
    
    
    
    

    @IBAction func mailEditing(_ sender: Any) {
        
        person.image = UIImage(named: "baseline_person_black_18dpProfile")
        email.image = UIImage(named: "baseline_email_orange_18dp")
        cake.image = UIImage(named: "baseline_cake_black_18dp")
        phone.image = UIImage(named: "baseline_phone_black_18dp")
        setBorder(textField: name, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        setBorder(textField: number, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        setBorder(textField: birthday, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        setBorder(textField: mail, color: #colorLiteral(red: 1, green: 0.5502320528, blue: 0, alpha: 1))
         map.image = UIImage(named: "map-black")
        
        setBorderToTextViewColor(textView: address, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
    
//        if isValidEmailAddress(emailAddressString: mail.text!){
//            emailValid = true
//        }else{
//            emailValid = false
//        }
//        
        
    }
    
    func isValidEmailAddress(emailAddressString: String) -> Bool {
        
        var returnValue = true
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        
        do {
            let regex = try NSRegularExpression(pattern: emailRegEx)
            let nsString = emailAddressString as NSString
            let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
            if results.count == 0
            {
                returnValue = false
            }
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            returnValue = false
        }
        return  returnValue
    }
    
    @IBAction func birthdayEditin(_ sender: Any) {
        
        person.image = UIImage(named: "baseline_person_black_18dpProfile")
        email.image = UIImage(named: "baseline_email_black_18dp")
        cake.image = UIImage(named: "baseline_cake_orange_18dp")
        phone.image = UIImage(named: "baseline_phone_black_18dp")
        map.image = UIImage(named: "map-black")
        setBorder(textField: name, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        setBorder(textField: number, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        setBorder(textField: birthday, color: #colorLiteral(red: 1, green: 0.5502320528, blue: 0, alpha: 1))
        setBorderToTextViewColor(textView: address, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
        setBorder(textField: mail, color: #colorLiteral(red: 0.6666666865, green: 0.6666666865, blue: 0.6666666865, alpha: 1))
    }
    
    
    
}
