//
//  EditProfileViewController.swift
//  application
//
//  Created by jabeed on 21/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}

extension UITextField {
    func setBottomBorderOnlyWith(color: CGColor) {
        self.borderStyle = .none
        self.layer.masksToBounds = false
        self.layer.shadowColor = color
        self.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        self.layer.shadowOpacity = 1.0
        self.layer.shadowRadius = 0.0
    }
}

extension EditProfileViewController: SendValueDelegate{
    func send(dic: [String : Any], tag: Int) {
        update(jsonDic: dic)
    }
}

struct details {
    var fname: String
    var lname: String
    var mname: String
    var mail: String
    var birthday: String
    var number: String
}


class EditProfileViewController: UIViewController, UITableViewDataSource, UITableViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate, UITextFieldDelegate,UITextViewDelegate{
    
    @IBOutlet weak var tableView: UITableView!
    
    var data = [details]()
    var mail = ""
    var number = ""
    var birthday = ""
    var gender = ""
    var address = ""
    var pimage = UIImage()
    
    
    var fname = ""
    var mname = ""
    var lname = ""
    
    var fini: Character = "K"
    var lini: Character = "P"
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 0 && indexPath.row == 0{
            pickImage()
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    let c = Bundle.main.loadNibNamed("CustomCell", owner: self, options: nil) as! [CustomCell]
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 0{
    
//        var c = Bundle.main.loadNibNamed("CustomCell", owner: self, options: nil) as! [CustomCell]
            
           let cell = c[0]
                cell.selectionStyle = UITableViewCell.SelectionStyle.none
            cell.profilePic.image = pimage
            cell.profilePic.layer.borderWidth = 1
            cell.profilePic.layer.masksToBounds = false
            cell.profilePic.layer.borderColor = UIColor.black.cgColor
            cell.profilePic.layer.cornerRadius = cell.profilePic.frame.height/2
            cell.profilePic.clipsToBounds = true
            

            return cell

        }  else{
//            let c =  Bundle.main.loadNibNamed("CustomCell", owner: self, options: nil) as! [CustomCell]
//
            let cell = c[1]
                cell.selectionStyle = UITableViewCell.SelectionStyle.none
//            cell.name.becomeFirstResponder()
            cell.birthday.inputView = datePicker
//            cell.birthday.inputAccessoryView = toolBar
            cell.birthday.delegate = self
            cell.number.delegate = self
            cell.address.delegate = self
            if mname.isEmpty && !fname.isEmpty && !lname.isEmpty {
                cell.name.text = fname + " " + lname
            }
            else if mname.isEmpty && !fname.isEmpty && lname.isEmpty {
                cell.name.text = fname
            }
            else{
                 cell.name.text = fname + " " + mname + " " + lname
            
            }
            print(cell.name.text)
//            adjustUITextViewHeight(arg: cell.address)
            setBorder(textField: cell.name)
            setBorder(textField: cell.number)
            setBorder(textField: cell.birthday)
            setBorder(textField: cell.mail)
            setBorderToTextView(textView: cell.address)

            if( gender == "M"){
                cell.mgender.isSelected = true
            }
            else {
                 cell.fgender.isSelected = true
            }
            cell.mail.text = mail
            cell.address.text = address
            cell.number.text = number
            cell.birthday.text = birthday
            
            
            cell.birthday.inputView = datePicker
//            cell.birthday.inputAccessoryView = toolBar
            
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0{
            return 190
        }
        else{
            return 550
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        data = [details(fname: fname,lname: lname,mname: mname, mail: mail, birthday: birthday, number: number)]
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        self.hideKeyboardWhenTappedAround()
    }
    
    
    @IBAction func cancel(_ sender: Any) {
          performSegue(withIdentifier : "unwind", sender: self)
    }
    
    func pickImage(){
        
        let imagePickerController =  UIImagePickerController()
        imagePickerController.delegate = self
        imagePickerController.allowsEditing = false
        
        let actionSheet = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        let camera = UIAlertAction(title: "Camera", style: .default) { action in
             imagePickerController.sourceType = .camera
             self.present(imagePickerController, animated: true, completion: nil)
        }
        
        let library = UIAlertAction(title: "Photo Library", style: .default) { action in
            imagePickerController.sourceType = .photoLibrary
            self.present(imagePickerController, animated: true, completion: nil)
        }
        
        let cancel = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        actionSheet.addAction(camera)
        actionSheet.addAction(library)
        actionSheet.addAction(cancel)
        present(actionSheet, animated: true, completion: nil)
    }
    
//
//    @objc private func imagePath(path: String, didFinishSavingWithError error: NSError?, contextInfo: UnsafeMutableRawPointer?) {
//        print(path) // That's the path you want
//    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        profilePic.imageChosed = true
       
        if (picker.sourceType == .camera) {
             let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage?
            let data = image!.pngData()
            profilePic.imageData = data!
            profilePic.compressedImage = image!
            UIImageWriteToSavedPhotosAlbum(image!,self, nil, nil)
            
            
//            let imageURL = info[UIImagePickerController.InfoKey.imageURL] as! NSURL
//            let imageName = imageURL.lastPathComponent
//            var documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
//            var localPath = URL(fileURLWithPath: documentDirectory, isDirectory: true).appendingPathComponent(imageName!)
//            do{
//                try data?.write(to: localPath)
//            }catch{
//                print("error")
//            }
             let index = IndexPath(row: 0, section: 0)
//            profilePic.imagePath = localPath.path
//            print(profilePic.imagePath)
//            //        let imageD = (image?.jpegData(compressionQuality: 0.75))!
//            //        profilePic.compressedImage = UIImage(data: imageD)!
//            //        profilePic.compressedImage.accessibilityIdentifier = "profilePic"
//            //        UIImageWriteToSavedPhotosAlbum(profilePic.compressedImage, nil, nil, nil)
//            let index = IndexPath(row: 0, section: 0)
//            //        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
//            //        let documentsDirectory = paths.first!
//            //        profilePic.imageURL = URL(fileURLWithPath: documentsDirectory).appendingPathComponent("profilePic")
//            //        profilePic.imagePath = profilePic.imageURL.path
//            //        print(profilePic.imagePath)
            let cell: CustomCell = self.tableView.cellForRow(at: index) as! CustomCell
            cell.profilePic.image = image
            profilePic.loadedImage = image!
            do{
            try? ImageStore.store(image: image!, name: "ProfilePic")
            }
            catch{
                print("error")
            }
            pimage = cell.profilePic.image!
            picker.dismiss(animated: true, completion: nil)
        }
        else if (picker.sourceType == .photoLibrary) {
             let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage?
        profilePic.compressedImage = image!
            profilePic.loadedImage = image!
            do{
                try? ImageStore.store(image: image!, name: "ProfilePic")
            }
            catch{
                print("error")
            }
        let imageData = image?.jpegData(compressionQuality: 0.75)
        profilePic.imageData = imageData!
        let imageURL = info[UIImagePickerController.InfoKey.imageURL] as! NSURL
        let imageName = imageURL.lastPathComponent
        var documentDirectory = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        var localPath = URL(fileURLWithPath: documentDirectory, isDirectory: true).appendingPathComponent(imageName!)
        do{
         try imageData?.write(to: localPath)
        }catch{
            print("error")
        }
        profilePic.imagePath = localPath.path
        print(profilePic.imagePath)
//        let imageD = (image?.jpegData(compressionQuality: 0.75))!
//        profilePic.compressedImage = UIImage(data: imageD)!
//        profilePic.compressedImage.accessibilityIdentifier = "profilePic"
//        UIImageWriteToSavedPhotosAlbum(profilePic.compressedImage, nil, nil, nil)
        let index = IndexPath(row: 0, section: 0)
//        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
//        let documentsDirectory = paths.first!
//        profilePic.imageURL = URL(fileURLWithPath: documentsDirectory).appendingPathComponent("profilePic")
//        profilePic.imagePath = profilePic.imageURL.path
//        print(profilePic.imagePath)
        let cell: CustomCell = self.tableView.cellForRow(at: index) as! CustomCell
        cell.profilePic.image = image
        pimage = cell.profilePic.image!
        picker.dismiss(animated: true, completion: nil)
    }
    }
    
    
//    [picker dismissModalViewControllerAnimated:YES];
//    imageView.image= [info objectForKey:@"UIImagePickerControllerOriginalImage"];
//    NSData *webData = UIImagePNGRepresentation(imageView.image);
//    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *documentsDirectory = [paths objectAtIndex:0];
//    NSString *localFilePath = [documentsDirectory stringByAppendingPathComponent:png];
//    [webData writeToFile:localFilePath atomically:YES];
//    NSLog(@"localFilePath.%@",localFilePath);
//
//    UIImage *image = [UIImage imageWithContentsOfFile:localFilePath];
    
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    let loadingView =  ViewControllerUtils()

    var imageName = ""
    
    var dobb = ""
    var saved = false
    @IBAction func save(_ sender: Any) {
        
        loadingView.showActivityIndicator(uiView: self.view)
        let index = IndexPath(row: 0, section: 1)
        let cell: CustomCell = self.tableView.cellForRow(at: index) as! CustomCell
        nameSeparate(n: cell.name.text!)
        
        self.number = cell.number.text!
        
        
        saved = true
        self.birthday = cell.birthday.text!
       
        
        if UserDefaults.standard.string(forKey: "dob") == nil{
            dobb = self.birthday
        }else{
            dobb = UserDefaults.standard.string(forKey: "dob")!
        }
        
        
//        UserDefaults.standard.set(str, forKey: "dob")
        self.mail = cell.mail.text!
        self.address = cell.address.text
        if cell.fgender.isSelected{
            self.gender = "F"
        }
        else if cell.mgender.isSelected{
            self.gender = "M"
        }
        let col1 = [
            "col":"mobile",
            "val":"\(self.number)"
        ]
        let col2 = ["col":"fname","val":"\(self.fname)"]
        let col3 = ["col":"mname","val":"\(self.mname)"]
        let col4 = ["col":"lname","val":"\(self.lname)"]
        let col5 = ["col":"email","val":"\(self.mail)"]
        let col6 = ["col":"dob","val": dobb]
        let col7 = ["col":"gender","val":"\(self.gender)"]
        let col8 = ["col":"address","val":"\(self.address)"]
        var ndx = IndexPath(row: 0, section: 1)
        let c: CustomCell = self.tableView.cellForRow(at: ndx) as! CustomCell
        
        
        if isValidNumber(num: c.number.text!) &&  c.number.text?.count == 10{
            
            if c.isValidEmailAddress(emailAddressString: c.mail.text!) {
                let u = [col1,col2,col3,col4,col5,col6,col7,col8]
                let filter = [["id","=","\(UserDefaults.standard.string(forKey: "contact_id")!)"]]
                let parameter: [String: Any] = ["u": u,"filter": filter]
                let d = connectServer.init(ur:"contactRoute.php?action=update",parameters: parameter,tag: 0)
                d.token = UserDefaults.standard.string(forKey: "token")!
                d.uid = UserDefaults.standard.string(forKey: "user_id")!
                d.bid = UserDefaults.standard.string(forKey: "bid")!
                d.post1()
                d.sendDelegate = self as SendValueDelegate
                
                if profilePic.imageChosed
                {
                    d.uploadImage(contactId: UserDefaults.standard.string(forKey: "contact_id")!)
                    d.sendDelegate = self as SendValueDelegate
                    profilePic.imageChosed = false
                }
                loadingView.hideActivityIndicator(uiView: self.view)
        
                performSegue(withIdentifier: "unwind", sender: self)
            }else{
                loadingView.hideActivityIndicator(uiView: self.view)
                setBorderColor(textField: c.mail, color: #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1))
                c.mail.isError(baseColor: #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1), numberOfShakes: 1, revert: true)
            }
        }
        else{
            
            if c.isValidEmailAddress(emailAddressString: c.mail.text!){
                loadingView.hideActivityIndicator(uiView: self.view)
                setBorderColor(textField: c.number, color: #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1))
                c.number.isError(baseColor: #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1), numberOfShakes: 1, revert: true)
            }
            else{
                loadingView.hideActivityIndicator(uiView: self.view)
                setBorderColor(textField: c.mail, color: #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1))
                c.mail.isError(baseColor: #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1), numberOfShakes: 1, revert: true)
                loadingView.hideActivityIndicator(uiView: self.view)
                setBorderColor(textField: c.number, color: #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1))
                c.number.isError(baseColor: #colorLiteral(red: 1, green: 0, blue: 0, alpha: 1), numberOfShakes: 1, revert: true)
            }
           
        }
        
    }
    
    func isValidEmailAddress(emailAddressString: String) -> Bool {
        
        var returnValue = true
        let emailRegEx = "[A-Z0-9a-z.-_]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,3}"
        
        do {
            let regex = try NSRegularExpression(pattern: emailRegEx)
            let nsString = emailAddressString as NSString
            let results = regex.matches(in: emailAddressString, range: NSRange(location: 0, length: nsString.length))
            if results.count == 0
            {
                returnValue = false
            }
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            returnValue = false
        }
        return  returnValue
    }
    
    func isValidNumber(num: String) -> Bool {
        
        var returnValue = true
        let numRegEx = "[9|8|7|6][0-9]{9}"
        //         let numRegEx = "\\A[0-9]{8}\\z"
        
        do {
            let regex = try NSRegularExpression(pattern: numRegEx)
            let nsString = num as NSString
            let results = regex.matches(in: num, range: NSRange(location: 0, length: nsString.length))
            if results.count == 0
            {
                returnValue = false
            }
        } catch let error as NSError {
            print("invalid regex: \(error.localizedDescription)")
            returnValue = false
        }
        return  returnValue
    }
    
    func nameSeparate(n: String){
        
        var names = n.split(separator: " ")
        
        if names.count == 2  {
            self.fname = String(names[0])
            self.lname = String(names[1])
            self.mname = ""
            fini = fname[fname.startIndex]
            lini = lname[lname.startIndex]
        }//first and last names provided
        else if names.count == 1{
             self.fname = String(names[0])
            fini = fname[fname.startIndex]
            self.lname = ""
            self.mname = ""
        } //only first name provided (or blank){
        else{
            self.mname = String(names[1])
            self.fname = String(names[0])
            self.lname = String(names[2])
        }
        
    }
    
    func update(jsonDic: [String:Any]){
        
        print(jsonDic)
        
    }

    
    lazy var datePicker: UIDatePicker =  {
        
        let picker = UIDatePicker()
        picker.maximumDate = Date()
        picker.datePickerMode = .date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-mm-YYYY"
        print(self.birthday)
        picker.date = dateFormatter.date(from: self.birthday)!
        picker.addTarget(self, action: #selector(datePickerChan), for: .valueChanged)
        
        return picker
        
    }()
    

//    lazy var toolBar: UIToolbar = {
//
//        let toolBar = UIToolbar(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: 40))
//        toolBar.barStyle = UIBarStyle.default
//        toolBar.tintColor = #colorLiteral(red: 0, green: 0.4784313725, blue: 1, alpha: 1)
//
//        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(done))
//        toolBar.setItems([doneButton], animated: true)
//
//        return toolBar
//    }()
    
//    @objc func donePressed(){
//
//        let index = IndexPath(row: 0, section: 1)
//        let cell: CustomCell = self.tableView.cellForRow(at: index) as! CustomCell
//        cell.birthday.resignFirstResponder()
//          view.endEditing(true)
//    }
    
    

    @objc func datePickerChanged(){
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .medium
        dateFormatter.dateFormat = "dd-mm-YYYY"
        dateFormatter.timeStyle = .none
        let index = IndexPath(row: 0, section: 1)
        let cell: CustomCell = self.tableView.cellForRow(at: index) as! CustomCell
        cell.birthday.text = dateFormatter.string(from: datePicker.date)
        
      

    }
    
    func setBorder(textField: UITextField){
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor.lightGray.cgColor
        border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width, height: textField.frame.size.height)
        border.borderWidth = width
        textField.layer.addSublayer(border)
        textField.layer.masksToBounds = true
    }
    
    func setBorderToTextView(textView: UITextView){
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor.lightGray.cgColor
        border.frame = CGRect(x: 0, y: textView.frame.size.height - width, width: textView.frame.size.width, height: textView.frame.size.height)
        border.borderWidth = width
        textView.layer.addSublayer(border)
        textView.layer.masksToBounds = true
    }
   
    func setBorderColor(textField: UITextField,color: CGColor){
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = color
        border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width, height: textField.frame.size.height)
        border.borderWidth = width
        textField.layer.addSublayer(border)
        textField.layer.masksToBounds = true
    }
    
    
    lazy var datePick: UIDatePicker =  {
        
        let picker = UIDatePicker()
        picker.maximumDate = Date()
        picker.datePickerMode = .date
        picker.locale = Locale(identifier: "en-GB")
        picker.addTarget(self, action: #selector(datePickerChanged), for: .valueChanged)
        
        return picker
        
    }()
    
//    lazy var tool: UIToolbar = {
//
//        let toolBar = UIToolbar(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: 40))
//        toolBar.barStyle = UIBarStyle.blackOpaque
//        toolBar.tintColor = #colorLiteral(red: 0, green: 0.4784313725, blue: 1, alpha: 1)
//        let doneButton = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
//        toolBar.setItems([doneButton], animated: true)
//
//        return toolBar
//    }()
//
//    @objc func done(){
//
//        let dateFormatter = DateFormatter()
//        dateFormatter.dateFormat = "dd-MM-yyyy"
//        let cell = c[1]
//        cell.birthday.text = dateFormatter.string(from: datePicker.date)
//        view.endEditing(true)
//        tableView.reloadData()
//    }
    
    @objc func datePickerChan(){
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy"
//        dateFormatter.dateStyle = .short
//        dateFormatter.timeStyle = .none
        //        cell.birthday.text = dateFormatter.string(from: datePicker.date)
        let b = NSString(string: dateFormatter.string(from: datePicker.date)) as String
        let birth = b.components(separatedBy: "-")
//        UserDefaults.standard.set(""\(birth[1])" + "-" + "\(birth[0])" + "-" + "\(birth[2])"", forKey: "db")
//        cell.birthday.text = birth[1] + "-" + birth[0] + "-" + birth[2]
        let cell = c[1]
        cell.birthday.text = dateFormatter.string(from: datePicker.date)
        print(cell.birthday.text!)
//        cell.birthday.text = b
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let str = dateFormatter.string(from: datePicker.date)
        UserDefaults.standard.set(str, forKey: "dob")
        self.birthday = str
        print(str)
//        view.endEditing(true)
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        
        if textField == c[1].number{
            let allowedCharacters = CharacterSet.decimalDigits
            let characterSet = CharacterSet(charactersIn: string)
            return allowedCharacters.isSuperset(of: characterSet)
        }
            return false; //do not show keyboard nor cursor
    }

    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y -= keyboardSize.height - 60
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if self.view.frame.origin.y != 0 {
            self.view.frame.origin.y = 0
        }
        
    }
    @objc func adjustForKeyboard(notification: Notification) {
        guard let keyboardValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue else { return }
        
        let keyboardScreenEndFrame = keyboardValue.cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == UIResponder.keyboardWillHideNotification {
            c[1].address.contentInset = .zero
        } else {
           c[1].address.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height - view.safeAreaInsets.bottom, right: 0)
        }
        
        c[1].address.scrollIndicatorInsets = c[1].address.contentInset
        
        let selectedRange = c[1].address.selectedRange
        c[1].address.scrollRangeToVisible(selectedRange)
    }
    
    func textViewDidChange(_ textView: UITextView) {
    
        setBorderToTextViewColor(textView: c[1].address, color: #colorLiteral(red: 1, green: 0.5502320528, blue: 0, alpha: 1))
        c[1].map.image = UIImage(named: "map_orange")
//
        if c[1].address.contentSize.height > c[1].address.frame.size.height {
            
            let fixedWidth =  c[1].address.frame.size.width
             c[1].address.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
            
            var newFrame =  c[1].address.frame
            let newSize = c[1].address.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
            
            newFrame.size = CGSize(width: max(newSize.width, fixedWidth), height: newSize.height)
            c[1].address.frame = newFrame;
        }
        
    }
    
    func setBorderToTextViewColor(textView: UITextView,color: CGColor){
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = color
        border.frame = CGRect(x: 0, y: textView.frame.size.height - width, width: textView.frame.size.width, height: textView.frame.size.height)
        border.borderWidth = width
        textView.layer.addSublayer(border)
        textView.layer.masksToBounds = true
    }
    
    func adjustUITextViewHeight(arg : UITextView)
    {
        arg.translatesAutoresizingMaskIntoConstraints = true
        arg.sizeToFit()
        arg.isScrollEnabled = false
    }

    
}
