//
//  ProfileTableViewCell.swift
//  application
//
//  Created by jabeed on 21/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

class ProfileTableViewCell: UITableViewCell {

    
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var labelIcon: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
