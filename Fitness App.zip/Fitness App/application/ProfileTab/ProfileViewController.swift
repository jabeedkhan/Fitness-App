//
//  ProfileViewController.swift
//  application
//
//  Created by jabeed on 20/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import UIKit

extension UIViewController {
    
    func showToast(message : String, font: UIFont) {
        
        let toastLabel = UILabel(frame: CGRect(x: self.view.frame.size.width/2 - 75, y: self.view.frame.size.height-100, width: 150, height: 35))
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.6)
        toastLabel.textColor = UIColor.white
        toastLabel.font = font
        toastLabel.textAlignment = .center;
        toastLabel.text = message
        toastLabel.alpha = 1.0
        toastLabel.layer.cornerRadius = 10;
        toastLabel.clipsToBounds  =  true
        self.view.addSubview(toastLabel)
        UIView.animate(withDuration: 3.0, delay: 1.5, options: .curveEaseOut, animations: {
            toastLabel.alpha = 0.0
        }, completion: {(isCompleted) in
            toastLabel.removeFromSuperview()
        })
    } }

extension UIImageView {
    
    func imageFromServerURL(_ URLString: String, placeHolder: UIImage?) {
        
        let imageCache = NSCache<NSString, UIImage>()
        self.image = nil
        if let cachedImage = imageCache.object(forKey: NSString(string: URLString)) {
            self.image = cachedImage
            return
        }
        
        if let url = URL(string: URLString) {
            URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
                
                //print("RESPONSE FROM API: \(response)")
                if error != nil {
                    print("ERROR LOADING IMAGES FROM URL: \(error)")
                    DispatchQueue.main.async {
                        self.image = placeHolder
                    }
                    return
                }
                DispatchQueue.main.async {
                    if let data = data {
                        if let downloadedImage = UIImage(data: data) {
                            imageCache.setObject(downloadedImage, forKey: NSString(string: URLString))
                            self.image = downloadedImage
                            profilePic.loadedImage = downloadedImage
                            do{
                            try? ImageStore.store(image: downloadedImage, name: "ProfilePic")
                            }
                            catch{
                                print("error")
                            }
                        }
                    }
                }
            }).resume()
        }
    }
}

extension ProfileViewController: SendValueDelegate{
    
    func send(dic: [String : Any], tag: Int) {
        setData(jsonDict: dic)
    }
}

struct profile {
   var label:String
    var icon: UIImage
}

class ProfileViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var data = [profile]()
    
    var fname = ""
    var lname = ""
    var mname = ""
    var dob = ""
    var email = ""
    var mobile = ""
    var gender = ""
    var address = ""

    let imageCache = NSCache<NSString, UIImage>()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "profileCell", for: indexPath) as! ProfileTableViewCell
        
        cell.label.text = data[indexPath.row].label
        
        cell.labelIcon.image = data[indexPath.row].icon
        
        return cell
    }
    
    
    @IBOutlet weak var ovalProfile: UIImageView!
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var initials: UILabel!
    @IBOutlet weak var image: UIImageView!
      let loadingView =  ViewControllerUtils()
    var haveLoaded = false
    override func viewDidLoad() {
        super.viewDidLoad()
//        loadingView.showActivityIndicator(uiView: self.view)
        
        if ImageStore.retrieve(imageNamed: imageName) != nil{
            haveLoaded = true
        }
//        loadingView.showSavedIndication(uiView: self.view)
        tableView.isScrollEnabled = false
        data = [profile(label: "Profile", icon: UIImage(named: "baseline_person_black_18dpProfile")!)]
        
        data.append(profile(label: "Courses", icon: UIImage(named: "courses")!))
        
        data.append(profile(label: "Terms", icon: UIImage(named: "terms")!))
        
        data.append(profile(label: "Feedback", icon: UIImage(named: "feedback")!))
        
        data.append(profile(label: "Logout", icon: UIImage(named: "baseline_exit_to_app_black_18dp")!))
        
        self.image.image = profilePic.loadedImage
        self.image.layer.cornerRadius = self.image.frame.size.width / 2;
        self.image.clipsToBounds = true;
        titleBar()
        
//        image.image = UIImage(named: "\(UserDefaults.standard.string(forKey: "profilePic")!)")
//        if (image.image != nil){
//            initials.isHidden = true
//        }
        name.text = UserDefaults.standard.string(forKey: "name")!
        
        let col = ["fname","lname","mname","mobile","email","image","dob","gender","address"]
        let filter = [["id","=","\(UserDefaults.standard.string(forKey: "contact_id")!)"]]
        
        let parameter: [String: Any] = ["col": col,"filter": filter]
        let d = connectServer.init(ur:"contactRoute.php?action=select",parameters: parameter,tag: 0)
        d.token = UserDefaults.standard.string(forKey: "token")!
        d.uid = UserDefaults.standard.string(forKey: "user_id")!
        d.bid = UserDefaults.standard.string(forKey: "bid")!
        d.post1()
        d.sendDelegate = self as SendValueDelegate
        
        image.layer.borderWidth = 1
        image.layer.masksToBounds = false
        image.layer.borderColor = UIColor.black.cgColor
        image.layer.cornerRadius = image.frame.height/2
        image.clipsToBounds = true
        
//        loadingView.hideSaved(uiView: self.view)
       
    }
    
    override func viewDidAppear(_ animated: Bool) {
       titleBar()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
//    func perform(dst: UIViewController){
//
//        let src = self as ProfileViewController
//        let dst = dst
//        src.view.superview?.insertSubview(dst.view, aboveSubview: src.view)
//        dst.view.transform = CGAffineTransform(translationX: src.view.frame.size.width, y: 0)
//        UIView.animate(withDuration: 0.5,
//                       delay: 0.0,
//                       options: UIView.AnimationOptions.curveEaseInOut,
//                       animations: {
//                        dst.view.transform = CGAffineTransform(translationX: 0, y: 0)
//        },
//                       completion: { finished in
//                        src.present(dst, animated: true, completion: nil)
//        }
//        )
//
//
//    }
      let Storyboard = UIStoryboard(name: "Main", bundle: nil)
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {

        if indexPath.row == 0{
            
        let EditProfilevc = Storyboard.instantiateViewController(withIdentifier: "editProfile") as! EditProfileViewController
            EditProfilevc.fname = fname
            EditProfilevc.lname = lname
            EditProfilevc.mname = mname
            EditProfilevc.mail = email
            EditProfilevc.birthday = dob
            EditProfilevc.number = mobile
            EditProfilevc.address = address
            EditProfilevc.gender = gender
            EditProfilevc.pimage = ImageStore.retrieve(imageNamed: "ProfilePic")!
            EditProfilevc.imageName = imageName
//            let transition = CATransition()
//            transition.duration = 0.43
//            transition.type = CATransitionType.push
//            transition.subtype = CATransitionSubtype.fromRight
//            transition.timingFunction = CAMediaTimingFunction(name:CAMediaTimingFunctionName.easeInEaseOut)
//            view.window!.layer.add(transition, forKey: kCATransition)
//            present(EditProfilevc, animated: false, completion: nil)
            
            self.navigationController?.pushViewController(EditProfilevc, animated: true)
    }
       else if indexPath.row == 1{
          
            let coursevc = Storyboard.instantiateViewController(withIdentifier: "course") as! CoursesViewController
//
//
//            let transition = CATransition()
//            transition.duration = 0.43
//            transition.type = CATransitionType.push
//            transition.subtype = CATransitionSubtype.fromRight
//            transition.timingFunction = CAMediaTimingFunction(name:CAMediaTimingFunctionName.easeInEaseOut)
//            view.window!.layer.add(transition, forKey: kCATransition)
//            present(coursevc, animated: false, completion: nil)
            
             self.navigationController?.pushViewController(coursevc, animated: true)
        }
        else if indexPath.row == 2{
            let termsvc = Storyboard.instantiateViewController(withIdentifier: "terms") as! TermsViewController
            
//            let transition = CATransition()
//            transition.duration = 0.43
//            transition.type = CATransitionType.push
//            transition.subtype = CATransitionSubtype.fromRight
//            transition.timingFunction = CAMediaTimingFunction(name:CAMediaTimingFunctionName.easeInEaseOut)
//            view.window!.layer.add(transition, forKey: kCATransition)
//
//
//            present(termsvc, animated: false, completion: nil)
             self.navigationController?.pushViewController(termsvc, animated: true)
        }
        else if indexPath.row == 3{
            let feedbackvc = Storyboard.instantiateViewController(withIdentifier: "feedback") as! FeedbackViewController
        
             self.navigationController?.pushViewController(feedbackvc, animated: true)
        }
        else if indexPath.row == 4{
            
            
            let refreshAlert = UIAlertController(title: "Logout", message: "Are you sure you want to logout?", preferredStyle: UIAlertController.Style.alert)
            
            refreshAlert.addAction(UIAlertAction(title: "Logout", style: .default, handler: { (action: UIAlertAction!) in
                
               
                UserDefaults.standard.set("", forKey: "login_user")
                UserDefaults.standard.set("", forKey: "login_password")
                
                let loginvc = self.Storyboard.instantiateViewController(withIdentifier: "login") as! LoginViewController
                self.navigationController?.present(loginvc, animated: true, completion: nil)
            }))
            
            refreshAlert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: { (action: UIAlertAction!) in
                tableView.deselectRow(at: indexPath, animated: true)
            }))
            
             self.present(refreshAlert, animated: true, completion: nil)
            
        }
    }
    
    
    func setData(jsonDict: [String: Any]){
    
        let data = jsonDict["data"] as?  [ [String:Any]]
        
        let d = data![0]
        fname = d["fname"] as! String
        lname = d["lname"] as! String
        mname = d["mname"] as! String
        dob = d["dob"] as! String
        email = d["email"] as! String
        gender = d["gender"] as! String
        mobile = d["mobile"] as! String
        address = d["address"] as! String
        imageName = d["image"] as! String
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        if dob  == "0000-00-00"{
           
            let datestr = formatter.string(from: Date())
            let dat = datestr.components(separatedBy: "-")
            dob = dat[2] + "-" + dat[1] + "-" + dat[0]
            
        }
        else{
            
            let date = formatter.date(from: dob)
            let datestr = formatter.string(from: date!)
            let dat = datestr.components(separatedBy: "-")
            //        UserDefaults.standard.set(""\(birth[1])" + "-" + "\(birth[0])" + "-" + "\(birth[2])"", forKey: "db")
            //        cell.birthday.text = birth[1] + "-" + birth[0] + "-" + birth[2]
            //        cell.birthday.text = birth[1] + "-" + birth[0] + "-" + birth[2]
            dob = dat[2] + "-" + dat[1] + "-" + dat[0]
          
        }
       
//        print(dob)
        
        if ImageStore.retrieve(imageNamed: "ProfilePic") != nil
        {
             image.image = ImageStore.retrieve(imageNamed: "ProfilePic")
        }
        else{
            let imageURL = "https://papa.fit/content/contact_images/" + (d["image"] as! String)
            image.imageFromServerURL(imageURL, placeHolder: UIImage(named: "baseline_receipt_black1_18dp-1"))
        }
      
//        profilePic.loadedImage = image.image!
//        loadingView.hideActivityIndicator(uiView: self.view)
//        let url = URL(string: imageURL)!
//        let da = try? Data(contentsOf: url)
//        if let imageData = da {
//            image.image = UIImage(data: imageData)
//            profilePic.loadedImage = image.image!
//        }

//        for (key, value) in UserDefaults.standard.dictionaryRepresentation() {
//            print("\(key) = \(value) \n")
//        }
    }
    @IBAction  func unwindToProfile(segue: UIStoryboardSegue){
        
        if let eviewController = segue.source as? EditProfileViewController{
            
            loadingView.showSavedIndication(uiView: self.view)
            name.text = eviewController.fname + " " + eviewController.lname
            fname = eviewController.fname
            lname = eviewController.lname
            mname = eviewController.mname
            dob = eviewController.dobb
            image.image = ImageStore.retrieve(imageNamed: "ProfilePic")
//            imageName = eviewController.imageName
            
            profilePic.loadedImage = image.image!
            initials.text  = "\(eviewController.fini)" + "\(eviewController.lini)"
            loadingView.hideSaved(uiView: self.view)
            
            let col = ["fname","mname","lname","mobile","email","image","dob","gender","address"]
            let filter = [["id","=","\(UserDefaults.standard.string(forKey: "contact_id")!)"]]
            let parameter: [String: Any] = ["col": col,"filter": filter]
            let d = connectServer.init(ur:"contactRoute.php?action=select",parameters: parameter,tag: 0)
            d.token = UserDefaults.standard.string(forKey: "token")!
            d.uid = UserDefaults.standard.string(forKey: "user_id")!
            d.bid = UserDefaults.standard.string(forKey: "bid")!
            d.post1()
            d.sendDelegate = self as SendValueDelegate
            if eviewController.saved{
                 self.showToast(message: "Saved", font: UIFont(name: "Helvetica", size: 10)!)
            }
           
            
            }
        if let coursesviewController = segue.source as? CoursesViewController{
            //
        }
           tableView.reloadData()
        }
    
    var imageName = ""

    func titleBar(){
        
        if let items = tabBarController?.tabBar.items {
            for item in items {
                item.title = ""
                  item.imageInsets = UIEdgeInsets(top: 0, left: 0, bottom: -10, right: 0)
            }
        }
        tabBarItem.title = "Profile"
        tabBarItem.imageInsets = UIEdgeInsets(top: 0, left: 0, bottom: -45, right: 0)
        
        
        
        
        let appearance = UITabBarItem.appearance()
        let attributes = [NSAttributedString.Key.font:UIFont(name: "Helvetica Bold", size: 15)]
        appearance.setTitleTextAttributes(attributes as [NSAttributedString.Key : Any], for: .normal)
//        
//        let col = ["fname","lname","mname","mobile","email","image","dob","gender","address"]
//        let filter = [["id","=","\(UserDefaults.standard.string(forKey: "contact_id")!)"]]
//        
//        let parameter: [String: Any] = ["col": col,"filter": filter]
//        let d = connectServer.init(ur:"contactRoute.php?action=select",parameters: parameter,tag: 0)
//        d.token = UserDefaults.standard.string(forKey: "token")!
//        d.uid = UserDefaults.standard.string(forKey: "user_id")!
//        d.bid = UserDefaults.standard.string(forKey: "bid")!
//        d.post1()
//        d.sendDelegate = self as SendValueDelegate
        
        
        
    }
    

}
