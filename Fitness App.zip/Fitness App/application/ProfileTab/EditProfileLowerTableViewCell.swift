//
//  EditProfileLowerTableViewCell.swift
//  FBSDKCoreKit
//
//  Created by jabeed on 21/06/19.
//

import UIKit

class EditProfileLowerTableViewCell: UITableViewCell {

    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var number: UITextField!
    
    @IBOutlet weak var mail: UITextField!
    
    @IBOutlet weak var birthday: UITextField!
    
    override func awakeFromNib() {
        super.awakeFromNib()

    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setBorder(textField: UITextField){
        
        let border = CALayer()
        let width = CGFloat(1.0)
        border.borderColor = UIColor.lightGray.cgColor
        border.frame = CGRect(x: 0, y: textField.frame.size.height - width, width: textField.frame.size.width, height: textField.frame.size.height)
        border.borderWidth = width
        textField.layer.addSublayer(border)
        textField.layer.masksToBounds = true
    }
    
    
    
    
    

}
