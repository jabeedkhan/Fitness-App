//
//  post.swift
//  loginPage
//
//  Created by jabeed on 14/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import Foundation
import UIKit
import MobileCoreServices
import AVFoundation

extension NSMutableData {
    func appendString(_ string: String) {
        let data = string.data(using: String.Encoding.utf8, allowLossyConversion: false)
        append(data!)
    }
}

protocol SendValueDelegate {
    func send(dic: [String: Any], tag: Int)
}

class connectServer:UIViewController{
    
    
    var token = ""
    var uid = ""
    var bid = ""
    var image =  UIImage()
    
    var sendDelegate: SendValueDelegate? = nil
    
    var ur = ""
    var parameters: [String: Any] = [:]
    var senderTag: Int? = nil
    
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    init(ur: String,parameters: [String: Any],tag: Int) {
        
        self.ur = ur
        self.senderTag = tag
        self.parameters = parameters
        super.init(nibName: nil, bundle: nil)
    }
    
    func posts(){
        
        guard let url = URL(string: "\(ServerConstants.ROUTES)\(ur)") else {return}
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        guard let httpbody = try? JSONSerialization.data(withJSONObject: parameters, options: []) else{return}
        request.httpBody = httpbody
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            

            
            if let response = response{
                print(response)
                print(response.mimeType!)
            }
            if let data = data{
                print(data)
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    DispatchQueue.main.sync {
                        let jsonDict = json as! [String: Any]
                        print(jsonDict)
                        self.sendDelegate!.send(dic: jsonDict, tag: self.senderTag!)
                    }
                }
                catch{
                    print(error)
                }
            }
            }.resume()
    }
    
    func post1(){
        
        let identifier = UIDevice.current.identifierForVendor?.uuidString
        guard let url = URL(string: "\(ServerConstants.ROUTES)\(ur)") else {return}
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("\(token)", forHTTPHeaderField: "token")
        request.setValue("\(uid)", forHTTPHeaderField: "uid")
        request.setValue("IA_\(String(describing: identifier))_iOS12.2", forHTTPHeaderField: "Device")
        request.setValue("\(bid)", forHTTPHeaderField: "bid")
        
        guard let httpbody = try? JSONSerialization.data(withJSONObject: parameters, options: []) else{return}
        request.httpBody = httpbody
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            
            if let response = response{
                print(response)
            }
            if let data = data{
                print(data)
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    DispatchQueue.main.sync {
                        let jsonDict = json as! [String: Any]
                        print(jsonDict)
                        self.sendDelegate!.send(dic: jsonDict, tag: self.senderTag!)
                    }
                }
                catch{
                    print(error)
                }
            }
            }.resume()
    }
    
    func uploadImage(contactId: String){
        
        
        let request: URLRequest
        
        do {
            request = try createRequest(contactId: contactId)
        } catch {
            print(error)
            return
        }
        print(request)

        let session = URLSession.shared
        session.dataTask(with: request) { (data, response, error) in
            
            if let response = response{
                print(response)
            }
            if let data = data{
                print(data)
                let str = String(bytes: data, encoding: .utf8)
                print(str)
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    DispatchQueue.main.sync {
                        let jsonDict = json as! [String: Any]
                        print(jsonDict)
                        self.sendDelegate!.send(dic: jsonDict, tag: self.senderTag!)
                    }
                }
                catch{
                    print(error)
                }
            }
            }.resume()
    }
    
    
    
    /// Create request
    ///
    /// - parameter userid:   The userid to be passed to web service
    /// - parameter password: The password to be passed to web service
    /// - parameter email:    The email address to be passed to web service
    ///
    /// - returns:            The `URLRequest` that was created
    
    func createRequest(contactId: String) throws -> URLRequest {
        
        print(contactId)
        let identifier = UIDevice.current.identifierForVendor?.uuidString
        let parameters = [
            "id"  : contactId,
            ]  // build your dictionary however appropriate
        
        let boundary = generateBoundaryString()
        
        let url = URL(string: "\(ServerConstants.ROUTES)/contactRoute.php?action=upload")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("\(token)", forHTTPHeaderField: "token")
        request.setValue("\(uid)", forHTTPHeaderField: "uid")
        request.setValue("IA_\(String(describing: identifier))_iOS12.2", forHTTPHeaderField: "Device")
        request.setValue("\(bid)", forHTTPHeaderField: "bid")
        
        let imData = profilePic.imageData
        
        let iurl = URL(fileURLWithPath: profilePic.imagePath)
        let filename = iurl.lastPathComponent
        print(filename)
        //            let filename = url.lastPathComponent
        //            print(filename)
        request.httpBody = createBody(parameters: parameters,
                                boundary: boundary,
                                d: imData,
                                mimeType: "image/jpg",
                                filename: filename)
//        let path1 = Bundle.main.path(forResource: profilePic.compressedImage.accessibilityIdentifier, ofType: "jpeg")!
//        request.httpBody = try createBody(with: parameters, filePathKey: "file", paths: [profilePic.imagePath], boundary: boundary)
        return request
    }
    
    /// Create body of the `multipart/form-data` request
    ///
    /// - parameter parameters:   The optional dictionary containing keys and values to be passed to web service
    /// - parameter filePathKey:  The optional field name to be used when uploading files. If you supply paths, you must supply filePathKey, too.
    /// - parameter paths:        The optional array of file paths of the files to be uploaded
    /// - parameter boundary:     The `multipart/form-data` boundary
    ///
    /// - returns:                The `Data` of the body of the request
    
    
    func createBody(parameters: [String: String],
                    boundary: String,
                    d: Data,
                    mimeType: String,
                    filename: String) -> Data {
        let body = NSMutableData()
        
        let boundaryPrefix = "--\(boundary)\r\n"

        for (key, value) in parameters {
            body.appendString(boundaryPrefix)
            body.appendString("Content-Disposition: form-data; name=\"\(key)\"\r\n")
            body.appendString("Content-Type: text/plain; charset=UTF-8\r\n\r\n")
            body.appendString("\(value)\r\n")
        }
        
        body.appendString(boundaryPrefix)
        body.appendString("Content-Disposition: form-data; name=\"file\"; filename=\"\(filename)\"\r\n")
        body.appendString("Content-Type: \(mimeType)\r\n")
        body.appendString("Content-Tranfer-Encoding: binary\r\n\r\n")
        body.append(d)
        body.appendString("\r\n")
        body.appendString("--".appending(boundary.appending("--")))
        
        return body as Data
    }

    
    
    
//    private func createBody(with parameters: [String: String]?, filePathKey: String, paths: [String], boundary: String) throws -> Data {
//        var body = Data()
//
//        if parameters != nil {
//            for (key, value) in parameters! {
//                body.append("--\(boundary)\r\n")
//                body.append("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
//                body.append("\(value)\r\n")
//            }
//        }
//
//        for path in paths {
//            let url = URL(fileURLWithPath: path)
//            let filename = url.lastPathComponent
//            print(filename)
//            let data = try Data(contentsOf: url)
//            let mimetype = mimeType(for: path)
//
//            body.append("--\(boundary)\r\n")
//            body.append("Content-Disposition: form-data; name=\"\(filePathKey)\"; filename=\"\(filename)\"\r\n")
//            body.append("Content-Type: \(mimetype)\r\n\r\n")
//            body.append(data)
//            body.append("\r\n")
//        }
//
//        body.append("--\(boundary)--\r\n")
//        return body
//    }
//
//    /// Create boundary string for multipart/form-data request
//    ///
//    /// - returns:            The boundary string that consists of "Boundary-" followed by a UUID string.
//
   func generateBoundaryString() -> String {
        return "Boundary-\(UUID().uuidString)"
    }
//
//    /// Determine mime type on the basis of extension of a file.
//    ///
//    /// This requires `import MobileCoreServices`.
//    ///
//    /// - parameter path:         The path of the file for which we are going to determine the mime type.
//    ///
//    /// - returns:                Returns the mime type if successful. Returns `application/octet-stream` if unable to determine mime type.
//
//    private func mimeType(for path: String) -> String {
//        let url = URL(fileURLWithPath: path)
//        let pathExtension = url.pathExtension
//
//        if let uti = UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, pathExtension as NSString, nil)?.takeRetainedValue() {
//            if let mimetype = UTTypeCopyPreferredTagWithClass(uti, kUTTagClassMIMEType)?.takeRetainedValue() {
//                return mimetype as String
//            }
//        }
//        return "application/octet-stream"
//    }
}





