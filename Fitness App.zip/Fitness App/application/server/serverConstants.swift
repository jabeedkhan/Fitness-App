//
//  serverConsts.swift
//  application
//
//  Created by jabeed on 14/06/19.
//  Copyright © 2019 jabeed. All rights reserved.
//

import Foundation

class ServerConstants {

    static var ROUTES = "https://dev.papa.fit/routes/"

}
