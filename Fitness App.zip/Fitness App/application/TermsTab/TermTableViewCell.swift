//
//  TermTableViewCell.swift
//  
//
//  Created by pratyush sharma on 22/06/19.
//

import UIKit

class TermTableViewCell: UITableViewCell {

    
    @IBOutlet weak var num: UILabel!
    @IBOutlet weak var icon: UIImageView!
    @IBOutlet weak var term: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
