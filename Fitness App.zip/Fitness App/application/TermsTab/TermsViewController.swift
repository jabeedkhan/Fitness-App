//
//  TermsViewController.swift
//  FBSDKCoreKit
//
//  Created by jabeed on 21/06/19.
//

import UIKit

extension TermsViewController: SendValueDelegate{
    
    func send(dic: [String : Any], tag: Int) {
        
        getTerms(jsonDic: dic)
    }
}

struct terms{
    
    var term: String
    var num: String
}

class TermsViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var loader = ViewControllerUtils()
    @IBOutlet weak var tableView: UITableView!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return  data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TermTableViewCell


        cell.term.text = data[indexPath.row].term
        cell.num.text = data[indexPath.row].num

        return cell

    }
    

    var data = [terms]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loader.showActivityIndicator(uiView: self.view)
//        data = [terms(term: "asdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdas as dasd asd asd as asd asdasdqwdedasd asd a.", num: "01")]
//        data.append(terms(term: "asdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdas as dasd asd asd as asd asdasdqwdedasd asd a.", num: "02"))
//        data.append(terms(term: "asdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdas as dasd asd asd as asd asdasdqwdedasd asd a.", num: "03"))
//        data.append(terms(term: "asdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdas as dasd asd asd as asd asdasdqwdedasd asd a.", num: "04"))
        
        let col = ["term"]
        let filter = [["bid","=",UserDefaults.standard.string(forKey: "bid")!]]
        let orderby = [["id","ASC"]]
        let table = "invoice_terms"
        
        let parameter: [String: Any] = ["col": col,"filter": filter,"orderby":orderby,"table":table]
        // let col = ["contact_id":UserDefaults.standard.string(forKey: "contact_id")!]
        //        let parameter: [String: Any] = ["contact_id":UserDefaults.standard.string(forKey: "contact_id")!]
        let d = connectServer.init(ur:"commonRoute.php?action=getSetting",parameters: parameter,tag: 0)
        d.token = UserDefaults.standard.string(forKey: "token")!
        d.uid = UserDefaults.standard.string(forKey: "user_id")!
        d.bid = UserDefaults.standard.string(forKey: "bid")!
        d.post1()
        d.sendDelegate = self as SendValueDelegate
        
        
        
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func backButton(_ sender: Any) {
          performSegue(withIdentifier : "unwind", sender: self)
    }
     var md: [[String:Any]] = [[:]]
    
    func getTerms(jsonDic: [String:Any])
    {
        
        let data1 = jsonDic["data"] as! [Any]
        md.remove(at: 0)
        for i in data1{
            md.append(i as! [String:Any])
        }
        print(md)
        var i = 0
        var j = ""
        for t in md{
            i += 1
            if i < 10 {
                j = "0\(i)"
            }
            else{
                 j  = "\(i)"
            }
           
            data.append(terms(term: t["term"] as! String, num: j))
        }
        tableView.reloadData()
        loader.hideActivityIndicator(uiView: self.view)
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
